@echo off
cd /d "%~dp0"
if exist SuperMarioBrosRecompiled.exe (
  start "" SuperMarioBrosRecompiled.exe
) else (
  echo The EXE is not built on this PC yet. Starting the build...
  call BUILD-EXE.bat
)
