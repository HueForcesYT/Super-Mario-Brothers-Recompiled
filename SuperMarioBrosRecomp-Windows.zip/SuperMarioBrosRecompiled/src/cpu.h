#pragma once
#include <cstdint>

class Bus;

// Cycle-counting 6502 core (official opcodes + the common undocumented ones).
class CPU {
public:
    uint8_t a = 0, x = 0, y = 0, sp = 0xFD, status = 0x24;
    uint16_t pc = 0;
    uint64_t totalCycles = 0;
    Bus* bus = nullptr;

    void reset();
    int step();          // returns cycles consumed
    void nmi();
    void irq();
    bool irqLine = false;

private:
    uint8_t read(uint16_t a);
    void write(uint16_t a, uint8_t v);
    void push(uint8_t v);
    uint8_t pop();
    void setZN(uint8_t v);
    bool flag(uint8_t f) const { return (status & f) != 0; }
    void setFlag(uint8_t f, bool v) { status = v ? (status | f) : (uint8_t)(status & ~f); }
};

enum : uint8_t { F_C = 1, F_Z = 2, F_I = 4, F_D = 8, F_B = 16, F_U = 32, F_V = 64, F_N = 128 };
