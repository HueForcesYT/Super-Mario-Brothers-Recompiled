#include "ppu.h"
#include <cstring>

const uint32_t kNesPalette[64] = {
0xFF626262,0xFF001FB2,0xFF2404C8,0xFF5200B2,0xFF730076,0xFF800024,0xFF730B00,0xFF522800,
0xFF244400,0xFF005700,0xFF005C00,0xFF005324,0xFF003C76,0xFF000000,0xFF000000,0xFF000000,
0xFFABABAB,0xFF0D57FF,0xFF4B30FF,0xFF8A13FF,0xFFBC08D6,0xFFD21269,0xFFC72E00,0xFF9D5400,
0xFF607B00,0xFF209800,0xFF00A300,0xFF009942,0xFF007DB4,0xFF000000,0xFF000000,0xFF000000,
0xFFFFFFFF,0xFF53AEFF,0xFF9085FF,0xFFD365FF,0xFFFF57FF,0xFFFF5DCF,0xFFFF7757,0xFFFA9E00,
0xFFBDC700,0xFF7AE700,0xFF43F611,0xFF26EF7E,0xFF2CD5F6,0xFF4E4E4E,0xFF000000,0xFF000000,
0xFFFFFFFF,0xFFB6E1FF,0xFFCED1FF,0xFFE9C3FF,0xFFFFBCFF,0xFFFFBDF4,0xFFFFC6C3,0xFFFFD59A,
0xFFE9E681,0xFFCEF481,0xFFB6FB9A,0xFFA9FAC3,0xFFA9F0F4,0xFFB8B8B8,0xFF000000,0xFF000000 };

void PPU::reset() {
    fine_x = 0; addrLatch = 0; ppuDataBuffer = 0;
    scanline = 0; cycle = 0;
    bgNextTileId = bgNextTileAttr = bgNextTileLo = bgNextTileHi = 0;
    bgShifterPatLo = bgShifterPatHi = bgShifterAttrLo = bgShifterAttrHi = 0;
    stat.reg = 0; mask.reg = 0; ctrl.reg = 0;
    vram.reg = 0; tram.reg = 0;
    frameCount = 0; frameComplete = false; nmiRequest = false;
    memset(framebuffer, 0, sizeof(framebuffer));
}

uint8_t PPU::ppuRead(uint16_t addr) {
    addr &= 0x3FFF;
    uint8_t data = 0;
    if (cart && cart->ppuRead(addr, data)) return data;
    if (addr <= 0x1FFF) return 0;
    if (addr <= 0x3EFF) {
        addr &= 0x0FFF;
        Mirror m = cart ? cart->mirror() : Mirror::Horizontal;
        int table = (addr >> 10) & 3;
        int page = 0;
        if (m == Mirror::Vertical) page = table & 1;
        else if (m == Mirror::Horizontal) page = (table >> 1) & 1;
        else if (m == Mirror::OneScreenHi) page = 1;
        else page = 0;
        return nameTable[page][addr & 0x03FF];
    }
    addr &= 0x001F;
    if (addr == 0x0010 || addr == 0x0014 || addr == 0x0018 || addr == 0x001C) addr = (uint16_t)(addr - 0x0010);
    return (uint8_t)(paletteRam[addr] & (mask.grayscale ? 0x30 : 0x3F));
}

void PPU::ppuWrite(uint16_t addr, uint8_t data) {
    addr &= 0x3FFF;
    if (cart && cart->ppuWrite(addr, data)) return;
    if (addr <= 0x1FFF) return;
    if (addr <= 0x3EFF) {
        addr &= 0x0FFF;
        Mirror m = cart ? cart->mirror() : Mirror::Horizontal;
        int table = (addr >> 10) & 3;
        int page = 0;
        if (m == Mirror::Vertical) page = table & 1;
        else if (m == Mirror::Horizontal) page = (table >> 1) & 1;
        else if (m == Mirror::OneScreenHi) page = 1;
        else page = 0;
        nameTable[page][addr & 0x03FF] = data;
        return;
    }
    addr &= 0x001F;
    if (addr == 0x0010 || addr == 0x0014 || addr == 0x0018 || addr == 0x001C) addr = (uint16_t)(addr - 0x0010);
    paletteRam[addr] = data;
}

uint8_t PPU::cpuRead(uint16_t addr, bool readonly) {
    uint8_t data = 0;
    switch (addr & 7) {
        case 2:
            data = (uint8_t)((stat.reg & 0xE0) | (ppuDataBuffer & 0x1F));
            if (!readonly) { stat.vblank = 0; addrLatch = 0; }
            break;
        case 4: data = oam[oamAddr]; break;
        case 7:
            data = ppuDataBuffer;
            ppuDataBuffer = ppuRead(vram.reg);
            if (vram.reg >= 0x3F00) data = ppuDataBuffer;
            if (!readonly) vram.reg = (uint16_t)(vram.reg + (ctrl.inc ? 32 : 1));
            break;
        default: break;
    }
    return data;
}

void PPU::cpuWrite(uint16_t addr, uint8_t data) {
    switch (addr & 7) {
        case 0:
            ctrl.reg = data;
            tram.nametable_x = ctrl.nt_x;
            tram.nametable_y = ctrl.nt_y;
            break;
        case 1: mask.reg = data; break;
        case 3: oamAddr = data; break;
        case 4: oam[oamAddr++] = data; break;
        case 5:
            if (addrLatch == 0) { fine_x = (uint8_t)(data & 0x07); tram.coarse_x = (uint16_t)(data >> 3); addrLatch = 1; }
            else { tram.fine_y = (uint16_t)(data & 0x07); tram.coarse_y = (uint16_t)(data >> 3); addrLatch = 0; }
            break;
        case 6:
            if (addrLatch == 0) { tram.reg = (uint16_t)(((data & 0x3F) << 8) | (tram.reg & 0x00FF)); addrLatch = 1; }
            else { tram.reg = (uint16_t)((tram.reg & 0xFF00) | data); vram.reg = tram.reg; addrLatch = 0; }
            break;
        case 7:
            ppuWrite(vram.reg, data);
            vram.reg = (uint16_t)(vram.reg + (ctrl.inc ? 32 : 1));
            break;
        default: break;
    }
}

void PPU::incScrollX() {
    if (!(mask.bg || mask.spr)) return;
    if (vram.coarse_x == 31) { vram.coarse_x = 0; vram.nametable_x = ~vram.nametable_x; }
    else vram.coarse_x++;
}

void PPU::incScrollY() {
    if (!(mask.bg || mask.spr)) return;
    if (vram.fine_y < 7) { vram.fine_y++; return; }
    vram.fine_y = 0;
    if (vram.coarse_y == 29) { vram.coarse_y = 0; vram.nametable_y = ~vram.nametable_y; }
    else if (vram.coarse_y == 31) vram.coarse_y = 0;
    else vram.coarse_y++;
}

void PPU::transferAddressX() {
    if (!(mask.bg || mask.spr)) return;
    vram.nametable_x = tram.nametable_x;
    vram.coarse_x = tram.coarse_x;
}

void PPU::transferAddressY() {
    if (!(mask.bg || mask.spr)) return;
    vram.fine_y = tram.fine_y;
    vram.nametable_y = tram.nametable_y;
    vram.coarse_y = tram.coarse_y;
}

void PPU::loadShifters() {
    bgShifterPatLo = (uint16_t)((bgShifterPatLo & 0xFF00) | bgNextTileLo);
    bgShifterPatHi = (uint16_t)((bgShifterPatHi & 0xFF00) | bgNextTileHi);
    bgShifterAttrLo = (uint16_t)((bgShifterAttrLo & 0xFF00) | ((bgNextTileAttr & 1) ? 0xFF : 0x00));
    bgShifterAttrHi = (uint16_t)((bgShifterAttrHi & 0xFF00) | ((bgNextTileAttr & 2) ? 0xFF : 0x00));
}

void PPU::updateShifters() {
    if (mask.bg) {
        bgShifterPatLo <<= 1; bgShifterPatHi <<= 1;
        bgShifterAttrLo <<= 1; bgShifterAttrHi <<= 1;
    }
    if (mask.spr && cycle >= 1 && cycle < 258) {
        for (int i = 0; i < lineSpriteCount; i++) {
            if (lineSprites[i].x > 0) lineSprites[i].x--;
            else { spriteShifterLo[i] <<= 1; spriteShifterHi[i] <<= 1; }
        }
    }
}

void PPU::clock() {
    if (scanline >= -1 && scanline < 240) {
        if (scanline == 0 && cycle == 0) cycle = 1;
        if (scanline == -1 && cycle == 1) {
            stat.vblank = 0; stat.sprite_zero_hit = 0; stat.sprite_overflow = 0;
            for (int i = 0; i < 8; i++) { spriteShifterLo[i] = 0; spriteShifterHi[i] = 0; }
        }
        if ((cycle >= 2 && cycle < 258) || (cycle >= 321 && cycle < 338)) {
            updateShifters();
            switch ((cycle - 1) % 8) {
                case 0:
                    loadShifters();
                    bgNextTileId = ppuRead((uint16_t)(0x2000 | (vram.reg & 0x0FFF)));
                    break;
                case 2:
                    bgNextTileAttr = ppuRead((uint16_t)(0x23C0 | (vram.nametable_y << 11) | (vram.nametable_x << 10)
                                     | ((vram.coarse_y >> 2) << 3) | (vram.coarse_x >> 2)));
                    if (vram.coarse_y & 0x02) bgNextTileAttr >>= 4;
                    if (vram.coarse_x & 0x02) bgNextTileAttr >>= 2;
                    bgNextTileAttr &= 0x03;
                    break;
                case 4:
                    bgNextTileLo = ppuRead((uint16_t)((ctrl.bg_pat << 12) + ((uint16_t)bgNextTileId << 4) + vram.fine_y));
                    break;
                case 6:
                    bgNextTileHi = ppuRead((uint16_t)((ctrl.bg_pat << 12) + ((uint16_t)bgNextTileId << 4) + vram.fine_y + 8));
                    break;
                case 7: incScrollX(); break;
                default: break;
            }
        }
        if (cycle == 256) incScrollY();
        if (cycle == 257) {
            loadShifters();
            if (scanline >= 0 && scanline < 240) { lineScrollX[scanline] = liveScrollX(); lineScrollY[scanline] = liveScrollY(); }
            transferAddressX();
        }
        if (cycle == 338 || cycle == 340) bgNextTileId = ppuRead((uint16_t)(0x2000 | (vram.reg & 0x0FFF)));
        if (scanline == -1 && cycle >= 280 && cycle < 305) transferAddressY();

        // sprite evaluation for the next scanline
        if (cycle == 257 && scanline >= 0) {
            memset(lineSprites, 0xFF, sizeof(lineSprites));
            lineSpriteCount = 0;
            spriteZeroPossible = false;
            for (int i = 0; i < 8; i++) { spriteShifterLo[i] = 0; spriteShifterHi[i] = 0; }
            uint8_t entry = 0;
            while (entry < 64 && lineSpriteCount < 9) {
                int diff = scanline - (int)oam[entry * 4 + 0];
                int h = ctrl.spr_size ? 16 : 8;
                if (diff >= 0 && diff < h) {
                    if (lineSpriteCount < 8) {
                        if (entry == 0) spriteZeroPossible = true;
                        lineSprites[lineSpriteCount].y = oam[entry * 4 + 0];
                        lineSprites[lineSpriteCount].id = oam[entry * 4 + 1];
                        lineSprites[lineSpriteCount].attr = oam[entry * 4 + 2];
                        lineSprites[lineSpriteCount].x = oam[entry * 4 + 3];
                        lineSpriteCount++;
                    } else stat.sprite_overflow = 1;
                }
                entry++;
            }
        }
        if (cycle == 340) {
            for (int i = 0; i < lineSpriteCount; i++) {
                uint16_t addrLo;
                bool flipV = (lineSprites[i].attr & 0x80) != 0;
                int row = scanline - (int)lineSprites[i].y;
                if (!ctrl.spr_size) {
                    addrLo = (uint16_t)((ctrl.spr_pat << 12) | ((uint16_t)lineSprites[i].id << 4)
                             | (flipV ? (7 - row) : row));
                } else {
                    int r = flipV ? (15 - row) : row;
                    uint16_t bank = (uint16_t)((lineSprites[i].id & 1) << 12);
                    uint16_t tile = (uint16_t)((lineSprites[i].id & 0xFE) + (r >= 8 ? 1 : 0));
                    addrLo = (uint16_t)(bank | (tile << 4) | (r & 7));
                }
                uint8_t lo = ppuRead(addrLo);
                uint8_t hi = ppuRead((uint16_t)(addrLo + 8));
                if (lineSprites[i].attr & 0x40) {
                    auto rev = [](uint8_t b) { b = (uint8_t)((b & 0xF0) >> 4 | (b & 0x0F) << 4);
                                               b = (uint8_t)((b & 0xCC) >> 2 | (b & 0x33) << 2);
                                               b = (uint8_t)((b & 0xAA) >> 1 | (b & 0x55) << 1); return b; };
                    lo = rev(lo); hi = rev(hi);
                }
                spriteShifterLo[i] = lo;
                spriteShifterHi[i] = hi;
            }
        }
    }

    if (scanline == 241 && cycle == 1) {
        stat.vblank = 1;
        if (ctrl.nmi) nmiRequest = true;
    }

    // compose pixel
    uint8_t bgPixel = 0, bgPalette = 0;
    if (mask.bg) {
        uint16_t bitMux = (uint16_t)(0x8000 >> fine_x);
        uint8_t p0 = (bgShifterPatLo & bitMux) ? 1 : 0;
        uint8_t p1 = (bgShifterPatHi & bitMux) ? 1 : 0;
        bgPixel = (uint8_t)((p1 << 1) | p0);
        uint8_t a0 = (bgShifterAttrLo & bitMux) ? 1 : 0;
        uint8_t a1 = (bgShifterAttrHi & bitMux) ? 1 : 0;
        bgPalette = (uint8_t)((a1 << 1) | a0);
        if (!mask.bg_left && cycle - 1 < 8) bgPixel = 0;
    }

    uint8_t fgPixel = 0, fgPalette = 0, fgPriority = 0;
    if (mask.spr) {
        spriteZeroRendered = false;
        for (int i = 0; i < lineSpriteCount; i++) {
            if (lineSprites[i].x != 0) continue;
            uint8_t p0 = (spriteShifterLo[i] & 0x80) ? 1 : 0;
            uint8_t p1 = (spriteShifterHi[i] & 0x80) ? 1 : 0;
            uint8_t px = (uint8_t)((p1 << 1) | p0);
            if (px == 0) continue;
            fgPixel = px;
            fgPalette = (uint8_t)((lineSprites[i].attr & 0x03) + 0x04);
            fgPriority = (lineSprites[i].attr & 0x20) ? 0 : 1;
            if (i == 0) spriteZeroRendered = true;
            break;
        }
        if (!mask.spr_left && cycle - 1 < 8) fgPixel = 0;
    }

    uint8_t pixel = 0, palette = 0;
    if (bgPixel == 0 && fgPixel > 0) { pixel = fgPixel; palette = fgPalette; }
    else if (bgPixel > 0 && fgPixel == 0) { pixel = bgPixel; palette = bgPalette; }
    else if (bgPixel > 0 && fgPixel > 0) {
        if (fgPriority) { pixel = fgPixel; palette = fgPalette; }
        else { pixel = bgPixel; palette = bgPalette; }
        if (spriteZeroPossible && spriteZeroRendered && mask.bg && mask.spr) {
            int start = (!(mask.bg_left || mask.spr_left)) ? 9 : 1;
            if (cycle >= start && cycle < 258) stat.sprite_zero_hit = 1;
        }
    }

    int px = cycle - 1, py = scanline;
    if (px >= 0 && px < 256 && py >= 0 && py < 240) {
        uint8_t idx = ppuRead((uint16_t)(0x3F00 + (palette << 2) + pixel)) & 0x3F;
        framebuffer[py * 256 + px] = kNesPalette[idx];
    }

    cycle++;
    if (cycle >= 341) {
        cycle = 0;
        scanline++;
        if (scanline >= 261) {
            scanline = -1;
            frameComplete = true;
            frameCount++;
        }
    }
}
