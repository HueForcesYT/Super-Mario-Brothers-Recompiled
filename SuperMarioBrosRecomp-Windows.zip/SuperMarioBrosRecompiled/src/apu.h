#pragma once
#include <cstdint>
#include <cstddef>
#include <vector>

class Bus;

// NES APU: 2 pulse, triangle, noise, DMC. Outputs mono float samples.
class APU {
public:
    Bus* bus = nullptr;
    void reset();
    void clock();                 // called once per CPU cycle
    void cpuWrite(uint16_t addr, uint8_t data);
    uint8_t readStatus();
    bool irqPending() const { return frameIrq || dmcIrq; }

    void setSampleRate(int hz);
    size_t available() const { return out.size(); }
    void drain(float* dst, size_t frames);
    void setEnabled(bool e) { enabled = e; }

private:
    struct Envelope { bool start=false, loop=false, constant=false; uint8_t volume=0, decay=0, divider=0;
        void clock(){ if(start){start=false;decay=15;divider=volume;} else if(divider){divider--;} else {divider=volume; if(decay) decay--; else if(loop) decay=15;} }
        uint8_t out() const { return constant ? volume : decay; } };
    struct Pulse { bool enabled=false; uint8_t duty=0, seq=0, lengthCounter=0; uint16_t timer=0, period=0;
        bool sweepEnable=false, sweepNegate=false, sweepReload=false; uint8_t sweepPeriod=0, sweepShift=0, sweepDivider=0;
        Envelope env; bool halt=false; int channel=1; uint8_t output=0;
        void clockTimer(); void clockSweep(); void clockLength(); };
    struct Triangle { bool enabled=false; uint16_t timer=0, period=0; uint8_t seq=0, lengthCounter=0, linear=0, linearReload=0;
        bool control=false, reloadFlag=false; uint8_t output=0;
        void clockTimer(); void clockLinear(); void clockLength(); };
    struct Noise { bool enabled=false, mode=false, halt=false; uint16_t shift=1, timer=0, period=0; uint8_t lengthCounter=0; Envelope env; uint8_t output=0;
        void clockTimer(); void clockLength(); };
    struct DMC { bool enabled=false, loop=false, irq=false, silence=true; uint16_t timer=0, period=428, addr=0, curAddr=0, length=0, bytesLeft=0;
        uint8_t buffer=0, shift=0, bitsLeft=0, level=0; bool bufferFilled=false; };

    Pulse p1, p2;
    Triangle tri;
    Noise noise;
    DMC dmc;
    bool frameIrq = false, dmcIrq = false, irqInhibit = false, fiveStep = false;
    uint32_t frameCounter = 0;
    uint64_t cycles = 0;
    int sampleRate = 44100;
    double sampleAccum = 0.0, samplePeriod = 0.0;
    std::vector<float> out;
    bool enabled = true;
    float lowPass = 0.0f, highPass = 0.0f, lastIn = 0.0f;

    void quarterFrame();
    void halfFrame();
    void mix();
};
