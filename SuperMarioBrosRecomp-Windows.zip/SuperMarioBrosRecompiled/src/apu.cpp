#include "apu.h"
#include "bus.h"
#include <cmath>
#include <cstring>

static const uint8_t kLengthTable[32] = {
10,254,20,2,40,4,80,6,160,8,60,10,14,12,26,14,12,16,24,18,48,20,96,22,192,24,72,26,16,28,32,30 };
static const uint8_t kDuty[4][8] = {{0,1,0,0,0,0,0,0},{0,1,1,0,0,0,0,0},{0,1,1,1,1,0,0,0},{1,0,0,1,1,1,1,1}};
static const uint8_t kTriSeq[32] = {15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
static const uint16_t kNoisePeriods[16] = {4,8,16,32,64,96,128,160,202,254,380,508,762,1016,2034,4068};
static const uint16_t kDmcRates[16] = {428,380,340,320,286,254,226,214,190,160,142,128,106,84,72,54};

void APU::Pulse::clockTimer() {
    if (timer == 0) { timer = period; seq = (uint8_t)((seq + 1) & 7); }
    else timer--;
    bool muted = (period < 8) || (period > 0x7FF) || lengthCounter == 0 || !enabled;
    output = (muted || !kDuty[duty][seq]) ? 0 : env.out();
}
void APU::Pulse::clockSweep() {
    if (sweepDivider == 0 && sweepEnable && sweepShift > 0) {
        uint16_t change = (uint16_t)(period >> sweepShift);
        if (sweepNegate) period = (uint16_t)(period - change - (channel == 1 ? 1 : 0));
        else if (period + change <= 0x7FF) period = (uint16_t)(period + change);
    }
    if (sweepDivider == 0 || sweepReload) { sweepDivider = sweepPeriod; sweepReload = false; }
    else sweepDivider--;
}
void APU::Pulse::clockLength() { if (lengthCounter && !halt) lengthCounter--; }

void APU::Triangle::clockTimer() {
    if (timer == 0) { timer = period; if (linear > 0 && lengthCounter > 0 && period >= 2) seq = (uint8_t)((seq + 1) & 31); }
    else timer--;
    output = (!enabled || period < 2) ? 0 : kTriSeq[seq];
}
void APU::Triangle::clockLinear() {
    if (reloadFlag) linear = linearReload; else if (linear) linear--;
    if (!control) reloadFlag = false;
}
void APU::Triangle::clockLength() { if (lengthCounter && !control) lengthCounter--; }

void APU::Noise::clockTimer() {
    if (timer == 0) {
        timer = period;
        uint16_t fb = (uint16_t)((shift & 1) ^ ((shift >> (mode ? 6 : 1)) & 1));
        shift = (uint16_t)((shift >> 1) | (fb << 14));
    } else timer--;
    output = ((shift & 1) || lengthCounter == 0 || !enabled) ? 0 : env.out();
}
void APU::Noise::clockLength() { if (lengthCounter && !halt) lengthCounter--; }

void APU::reset() {
    p1 = Pulse(); p2 = Pulse(); p2.channel = 2;
    tri = Triangle(); noise = Noise(); dmc = DMC();
    noise.shift = 1;
    frameIrq = dmcIrq = irqInhibit = fiveStep = false;
    frameCounter = 0; cycles = 0;
    out.clear();
    sampleAccum = 0.0;
    setSampleRate(sampleRate);
}

void APU::setSampleRate(int hz) {
    sampleRate = hz > 0 ? hz : 44100;
    samplePeriod = 1789773.0 / (double)sampleRate;   // NTSC CPU clock
}

void APU::cpuWrite(uint16_t addr, uint8_t data) {
    switch (addr) {
        case 0x4000: case 0x4004: {
            Pulse& p = (addr == 0x4000) ? p1 : p2;
            p.duty = (uint8_t)((data >> 6) & 3);
            p.halt = (data & 0x20) != 0;
            p.env.loop = p.halt;
            p.env.constant = (data & 0x10) != 0;
            p.env.volume = (uint8_t)(data & 0x0F);
            break;
        }
        case 0x4001: case 0x4005: {
            Pulse& p = (addr == 0x4001) ? p1 : p2;
            p.sweepEnable = (data & 0x80) != 0;
            p.sweepPeriod = (uint8_t)((data >> 4) & 7);
            p.sweepNegate = (data & 0x08) != 0;
            p.sweepShift = (uint8_t)(data & 7);
            p.sweepReload = true;
            break;
        }
        case 0x4002: case 0x4006: {
            Pulse& p = (addr == 0x4002) ? p1 : p2;
            p.period = (uint16_t)((p.period & 0xFF00) | data);
            break;
        }
        case 0x4003: case 0x4007: {
            Pulse& p = (addr == 0x4003) ? p1 : p2;
            p.period = (uint16_t)((p.period & 0x00FF) | ((data & 7) << 8));
            if (p.enabled) p.lengthCounter = kLengthTable[(data >> 3) & 0x1F];
            p.seq = 0;
            p.env.start = true;
            break;
        }
        case 0x4008: tri.control = (data & 0x80) != 0; tri.linearReload = (uint8_t)(data & 0x7F); break;
        case 0x400A: tri.period = (uint16_t)((tri.period & 0xFF00) | data); break;
        case 0x400B:
            tri.period = (uint16_t)((tri.period & 0x00FF) | ((data & 7) << 8));
            if (tri.enabled) tri.lengthCounter = kLengthTable[(data >> 3) & 0x1F];
            tri.reloadFlag = true;
            break;
        case 0x400C:
            noise.halt = (data & 0x20) != 0;
            noise.env.loop = noise.halt;
            noise.env.constant = (data & 0x10) != 0;
            noise.env.volume = (uint8_t)(data & 0x0F);
            break;
        case 0x400E: noise.mode = (data & 0x80) != 0; noise.period = kNoisePeriods[data & 0x0F]; break;
        case 0x400F: if (noise.enabled) noise.lengthCounter = kLengthTable[(data >> 3) & 0x1F]; noise.env.start = true; break;
        case 0x4010: dmc.irq = (data & 0x80) != 0; dmc.loop = (data & 0x40) != 0; dmc.period = kDmcRates[data & 0x0F]; if (!dmc.irq) dmcIrq = false; break;
        case 0x4011: dmc.level = (uint8_t)(data & 0x7F); break;
        case 0x4012: dmc.addr = (uint16_t)(0xC000 + ((uint16_t)data << 6)); break;
        case 0x4013: dmc.length = (uint16_t)(((uint16_t)data << 4) + 1); break;
        case 0x4015:
            p1.enabled = (data & 1) != 0;  if (!p1.enabled) p1.lengthCounter = 0;
            p2.enabled = (data & 2) != 0;  if (!p2.enabled) p2.lengthCounter = 0;
            tri.enabled = (data & 4) != 0; if (!tri.enabled) tri.lengthCounter = 0;
            noise.enabled = (data & 8) != 0; if (!noise.enabled) noise.lengthCounter = 0;
            dmc.enabled = (data & 16) != 0;
            if (!dmc.enabled) dmc.bytesLeft = 0;
            else if (dmc.bytesLeft == 0) { dmc.curAddr = dmc.addr; dmc.bytesLeft = dmc.length; }
            dmcIrq = false;
            break;
        case 0x4017:
            fiveStep = (data & 0x80) != 0;
            irqInhibit = (data & 0x40) != 0;
            if (irqInhibit) frameIrq = false;
            frameCounter = 0;
            if (fiveStep) { quarterFrame(); halfFrame(); }
            break;
        default: break;
    }
}

uint8_t APU::readStatus() {
    uint8_t s = 0;
    if (p1.lengthCounter) s |= 1;
    if (p2.lengthCounter) s |= 2;
    if (tri.lengthCounter) s |= 4;
    if (noise.lengthCounter) s |= 8;
    if (dmc.bytesLeft) s |= 16;
    if (frameIrq) s |= 64;
    if (dmcIrq) s |= 128;
    frameIrq = false;
    return s;
}

void APU::quarterFrame() { p1.env.clock(); p2.env.clock(); noise.env.clock(); tri.clockLinear(); }
void APU::halfFrame() {
    p1.clockLength(); p2.clockLength(); tri.clockLength(); noise.clockLength();
    p1.clockSweep(); p2.clockSweep();
}

void APU::mix() {
    float pulseOut = 0.0f;
    int pSum = p1.output + p2.output;
    if (pSum) pulseOut = 95.88f / ((8128.0f / (float)pSum) + 100.0f);
    float tnd = 0.0f;
    float t = (float)tri.output / 8227.0f + (float)noise.output / 12241.0f + (float)dmc.level / 22638.0f;
    if (t > 0.0f) tnd = 159.79f / (1.0f / t + 100.0f);
    float sample = pulseOut + tnd;
    // simple DC blocker + smoothing so cheap speakers do not buzz
    highPass = highPass * 0.996f + (sample - lastIn);
    lastIn = sample;
    lowPass += (highPass - lowPass) * 0.55f;
    out.push_back(enabled ? lowPass * 1.6f : 0.0f);
    if (out.size() > 65536) out.erase(out.begin(), out.begin() + 32768);
}

void APU::clock() {
    cycles++;
    bool apuCycle = (cycles & 1) == 0;
    if (apuCycle) { p1.clockTimer(); p2.clockTimer(); noise.clockTimer(); }
    tri.clockTimer();

    // DMC
    if (dmc.timer == 0) {
        dmc.timer = dmc.period;
        if (!dmc.silence) {
            if (dmc.shift & 1) { if (dmc.level <= 125) dmc.level += 2; }
            else { if (dmc.level >= 2) dmc.level -= 2; }
            dmc.shift >>= 1;
        }
        if (dmc.bitsLeft) dmc.bitsLeft--;
        if (dmc.bitsLeft == 0) {
            dmc.bitsLeft = 8;
            if (dmc.bufferFilled) { dmc.shift = dmc.buffer; dmc.bufferFilled = false; dmc.silence = false; }
            else dmc.silence = true;
        }
    } else dmc.timer--;
    if (!dmc.bufferFilled && dmc.bytesLeft > 0 && bus) {
        dmc.buffer = bus->cpuRead(dmc.curAddr);
        dmc.bufferFilled = true;
        dmc.curAddr = (uint16_t)(dmc.curAddr == 0xFFFF ? 0x8000 : dmc.curAddr + 1);
        dmc.bytesLeft--;
        if (dmc.bytesLeft == 0) {
            if (dmc.loop) { dmc.curAddr = dmc.addr; dmc.bytesLeft = dmc.length; }
            else if (dmc.irq) dmcIrq = true;
        }
    }

    // frame sequencer (approximated on CPU cycles)
    frameCounter++;
    if (!fiveStep) {
        if (frameCounter == 7457) quarterFrame();
        else if (frameCounter == 14913) { quarterFrame(); halfFrame(); }
        else if (frameCounter == 22371) quarterFrame();
        else if (frameCounter >= 29829) {
            quarterFrame(); halfFrame();
            if (!irqInhibit) frameIrq = true;
            frameCounter = 0;
        }
    } else {
        if (frameCounter == 7457) quarterFrame();
        else if (frameCounter == 14913) { quarterFrame(); halfFrame(); }
        else if (frameCounter == 22371) quarterFrame();
        else if (frameCounter >= 37281) { quarterFrame(); halfFrame(); frameCounter = 0; }
    }

    sampleAccum += 1.0;
    if (sampleAccum >= samplePeriod) { sampleAccum -= samplePeriod; mix(); }
}

void APU::drain(float* dst, size_t frames) {
    size_t n = frames < out.size() ? frames : out.size();
    for (size_t i = 0; i < n; i++) dst[i] = out[i];
    for (size_t i = n; i < frames; i++) dst[i] = n ? out[n - 1] * 0.5f : 0.0f;
    out.erase(out.begin(), out.begin() + n);
}
