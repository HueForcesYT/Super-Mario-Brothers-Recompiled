#include "bus.h"

Bus::Bus() {
    cpu.bus = this;
    apu.bus = this;
    ppu.cart = &cart;
}

bool Bus::loadRom(const std::string& path, std::string& err) {
    if (!cart.loadFile(path, err)) return false;
    ppu.cart = &cart;
    reset();
    return true;
}

void Bus::reset() {
    cart.reset();
    ppu.reset();
    apu.reset();
    cpu.reset();
    systemClock = 0;
    dmaActive = false; dmaDummy = true;
    for (int i = 0; i < 2048; i++) ram[i] = 0;
}

uint8_t Bus::cpuRead(uint16_t addr) {
    uint8_t data = 0;
    if (cart.cpuRead(addr, data)) return data;
    if (addr <= 0x1FFF) return ram[addr & 0x07FF];
    if (addr <= 0x3FFF) return ppu.cpuRead(addr & 0x0007);
    if (addr == 0x4015) return apu.readStatus();
    if (addr == 0x4016 || addr == 0x4017) {
        int i = addr & 1;
        uint8_t v = (controllerLatch[i] & 0x80) ? 1 : 0;
        controllerLatch[i] = (uint8_t)(controllerLatch[i] << 1);
        return (uint8_t)(v | 0x40);
    }
    return 0;
}

void Bus::cpuWrite(uint16_t addr, uint8_t data) {
    if (cart.cpuWrite(addr, data)) return;
    if (addr <= 0x1FFF) { ram[addr & 0x07FF] = data; return; }
    if (addr <= 0x3FFF) { ppu.cpuWrite(addr & 0x0007, data); return; }
    if (addr == 0x4014) { dmaPage = data; dmaAddr = 0; dmaActive = true; dmaDummy = true; return; }
    if (addr == 0x4016) {
        controllerLatch[0] = controller[0];
        controllerLatch[1] = controller[1];
        return;
    }
    if ((addr >= 0x4000 && addr <= 0x4013) || addr == 0x4015 || addr == 0x4017) { apu.cpuWrite(addr, data); return; }
}

void Bus::stepFrame() {
    do {
        ppu.clock();
        if (systemClock % 3 == 0) {          // one CPU tick every 3 PPU dots
            if (dmaActive) {
                if (dmaDummy) {
                    if (systemClock % 2 == 1) dmaDummy = false;
                } else if (systemClock % 2 == 0) {
                    dmaData = cpuRead((uint16_t)((dmaPage << 8) | dmaAddr));
                } else {
                    ppu.oam[dmaAddr] = dmaData;
                    dmaAddr++;
                    if (dmaAddr == 0) { dmaActive = false; dmaDummy = true; }
                }
            } else {
                if (cpuStall == 0) cpuStall = cpu.step();   // instruction cost, spent one tick at a time
                if (cpuStall > 0) cpuStall--;
            }
            apu.clock();
            if (apu.irqPending()) cpu.irq();
        }
        if (ppu.nmiRequest) { ppu.nmiRequest = false; cpu.nmi(); }
        systemClock++;
    } while (!ppu.frameComplete);
    ppu.frameComplete = false;
}
