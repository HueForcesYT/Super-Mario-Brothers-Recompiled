#include "widenes.h"
#include <algorithm>
#include <cmath>

WideNES::WideNES() : canvas((size_t)CANVAS_W * CANVAS_H, 0xFF000000u), known((size_t)CANVAS_W * CANVAS_H, 0), live(256u * 240u, 0xFF000000u) { reset(); }
void WideNES::clearCanvas() { std::fill(canvas.begin(), canvas.end(), 0xFF000000u); std::fill(known.begin(), known.end(), 0); }
void WideNES::beginScene() { clearCanvas(); camX = CANVAS_W / 2 - 128; camY = CANVAS_H / 2 - 120; lastScrollX = lastScrollY = -1; padLeft = padRight = padTop = padBottom = 0; scenes++; }
void WideNES::reset() { clearCanvas(); std::fill(live.begin(), live.end(), 0xFF000000u); camX = CANVAS_W / 2 - 128; camY = CANVAS_H / 2 - 120; lastScrollX = lastScrollY = -1; lastHash = 0; padLeft = padRight = padTop = padBottom = 0; scenes = 0; }

uint64_t WideNES::perceptualHash(const PPU& ppu) const {
    uint64_t h = 0;
    // 8x8 average-luma signature, deliberately insensitive to sprites and animation.
    int sum[64] = {}; int total = 0;
    for (int by = 0; by < 8; by++) for (int bx = 0; bx < 8; bx++) {
        for (int y = 0; y < 30; y++) for (int x = 0; x < 32; x++) {
            uint32_t c = ppu.framebuffer[(by * 30 + y) * 256 + bx * 32 + x];
            sum[by * 8 + bx] += (int)(((c >> 16 & 255) * 3 + (c >> 8 & 255) * 6 + (c & 255)) / 10);
        }
        total += sum[by * 8 + bx];
    }
    int avg = total / 64;
    for (int i = 0; i < 64; i++) if (sum[i] >= avg) h |= 1ull << i;
    return h;
}

void WideNES::detectPadding(const PPU& ppu) {
    int mid = ppu.lineScrollX[200];
    int top = 0, bottom = 0;
    while (top < 80 && std::abs((int)ppu.lineScrollX[top] - mid) > 4) top++;
    while (bottom < 80 && std::abs((int)ppu.lineScrollX[239 - bottom] - mid) > 4) bottom++;
    padTop = (padTop * 3 + top) / 4;
    padBottom = (padBottom * 3 + bottom) / 4;
    padLeft = 0; padRight = 0;
}

void WideNES::submitFrame(const PPU& ppu) {
    if (!enabled) return;
    live.assign(ppu.framebuffer, ppu.framebuffer + 256 * 240);
    if (!ppu.renderingOn()) return;
    detectPadding(ppu);
    uint64_t hash = perceptualHash(ppu);
    int sx = ppu.lineScrollX[200] & 0x1FF, sy = ppu.lineScrollY[200] % 480;
    if (lastScrollX < 0) { lastScrollX = sx; lastScrollY = sy; lastHash = hash; }
    int dx = sx - lastScrollX, dy = sy - lastScrollY;
    if (dx > 256) dx -= 512; if (dx < -256) dx += 512;
    if (dy > 240) dy -= 480; if (dy < -240) dy += 480;
    int changed = __builtin_popcountll(hash ^ lastHash);
    lastScrollX = sx; lastScrollY = sy; lastHash = hash;
    // ANESE-style scene transition heuristic: a large visual discontinuity plus
    // a non-scroll jump starts a fresh scene instead of smearing frames together.
    if (changed > 38 && (std::abs(dx) > 48 || std::abs(dy) > 48)) { beginScene(); return; }
    camX = std::clamp(camX + dx, 32, CANVAS_W - 288);
    camY = std::clamp(camY + dy, 32, CANVAS_H - 272);
    int y0 = std::clamp(padTop, 0, 100), y1 = 240 - std::clamp(padBottom, 0, 100);
    for (int y = y0; y < y1; y++) for (int x = 0; x < 256; x++) {
        int cx = camX + x, cy = camY + y;
        if (cx < 0 || cx >= CANVAS_W || cy < 0 || cy >= CANVAS_H) continue;
        size_t i = (size_t)cy * CANVAS_W + cx;
        // Never overwrite known pixels unless the new sample is inside the live window.
        canvas[i] = live[(size_t)y * 256 + x]; known[i] = 1;
    }
}

void WideNES::blitViewport(uint32_t* dst, int viewW, int viewH, float zoom, int panX, int panY) const {
    zoom = std::max(0.25f, zoom);
    float cx = camX + 128.0f + panX, cy = camY + 120.0f + panY;
    for (int y = 0; y < viewH; y++) for (int x = 0; x < viewW; x++) {
        int ix = std::clamp((int)(cx + (x - viewW * .5f) / zoom), 0, CANVAS_W - 1);
        int iy = std::clamp((int)(cy + (y - viewH * .5f) / zoom), 0, CANVAS_H - 1);
        size_t i = (size_t)iy * CANVAS_W + ix;
        // Unknown map pixels remain transparent-black: no invented/repeated art.
        dst[(size_t)y * viewW + x] = known[i] ? canvas[i] : 0xFF101218u;
    }
}
