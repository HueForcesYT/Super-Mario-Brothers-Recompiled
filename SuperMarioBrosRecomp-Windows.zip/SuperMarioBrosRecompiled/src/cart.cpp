#include "cart.h"
#include <cstdio>
#include <cstring>

static uint32_t crc32buf(const uint8_t* d, size_t n) {
    static uint32_t tab[256];
    static bool init = false;
    if (!init) {
        for (uint32_t i = 0; i < 256; i++) {
            uint32_t c = i;
            for (int k = 0; k < 8; k++) c = (c & 1) ? 0xEDB88320u ^ (c >> 1) : (c >> 1);
            tab[i] = c;
        }
        init = true;
    }
    uint32_t c = 0xFFFFFFFFu;
    for (size_t i = 0; i < n; i++) c = tab[(c ^ d[i]) & 0xFF] ^ (c >> 8);
    return c ^ 0xFFFFFFFFu;
}

bool Cart::loadFile(const std::string& path, std::string& err) {
    FILE* f = fopen(path.c_str(), "rb");
    if (!f) { err = "Could not open file: " + path; return false; }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (sz <= 16) { fclose(f); err = "File is too small to be a .nes ROM."; return false; }
    std::vector<uint8_t> data((size_t)sz);
    size_t got = fread(data.data(), 1, (size_t)sz, f);
    fclose(f);
    data.resize(got);
    size_t slash = path.find_last_of("/\\\\");
    m_title = (slash == std::string::npos) ? path : path.substr(slash + 1);
    return loadBytes(data, err);
}

bool Cart::loadBytes(const std::vector<uint8_t>& data, std::string& err) {
    m_valid = false;
    if (data.size() < 16 || memcmp(data.data(), "NES\x1A", 4) != 0) {
        err = "Not an iNES ROM (missing NES header). Only real .nes dumps are accepted.";
        return false;
    }
    m_prgBanks = data[4];
    m_chrBanks = data[5];
    uint8_t f6 = data[6], f7 = data[7];
    m_mapper = (uint8_t)((f7 & 0xF0) | (f6 >> 4));
    bool trainer = (f6 & 0x04) != 0;
    m_mirror = (f6 & 0x08) ? Mirror::FourScreen : ((f6 & 0x01) ? Mirror::Vertical : Mirror::Horizontal);

    size_t off = 16 + (trainer ? 512 : 0);
    size_t prgSize = (size_t)m_prgBanks * 16384;
    size_t chrSize = (size_t)m_chrBanks * 8192;
    if (prgSize == 0 || data.size() < off + prgSize) { err = "ROM is truncated or corrupt (PRG data missing)."; return false; }

    m_prg.assign(data.begin() + off, data.begin() + off + prgSize);
    off += prgSize;
    if (chrSize > 0 && data.size() >= off + chrSize) {
        m_chr.assign(data.begin() + off, data.begin() + off + chrSize);
        m_chrRam = false;
    } else {
        m_chr.assign(8192, 0);
        m_chrRam = true;
    }
    m_pram.assign(8192, 0);
    m_crc = crc32buf(data.data(), data.size());

    switch (m_mapper) {
        case 0: case 1: case 2: case 3: case 7: break;
        default: {
            char b[96];
            snprintf(b, sizeof(b), "Mapper %u is not supported yet (supported: 0,1,2,3,7).", m_mapper);
            err = b;
            return false;
        }
    }
    reset();
    m_valid = true;
    return true;
}

void Cart::reset() {
    m_bankSelect = 0; m_chrSelect = 0;
    m_shift = 0x10; m_control = 0x0C; m_chr0 = 0; m_chr1 = 0; m_prgBank = 0;
}

Mirror Cart::mirror() const {
    if (m_mapper == 1) {
        switch (m_control & 3) {
            case 0: return Mirror::OneScreenLo;
            case 1: return Mirror::OneScreenHi;
            case 2: return Mirror::Vertical;
            default: return Mirror::Horizontal;
        }
    }
    if (m_mapper == 7) return (m_bankSelect & 0x10) ? Mirror::OneScreenHi : Mirror::OneScreenLo;
    return m_mirror;
}

bool Cart::cpuRead(uint16_t addr, uint8_t& out) {
    if (addr >= 0x6000 && addr <= 0x7FFF) { out = m_pram[addr & 0x1FFF]; return true; }
    if (addr < 0x8000) return false;
    size_t idx = 0;
    switch (m_mapper) {
        case 0: case 3:
            idx = (m_prgBanks == 1) ? (addr & 0x3FFF) : (addr & 0x7FFF);
            break;
        case 2:
            idx = (addr < 0xC000) ? ((size_t)(m_bankSelect % m_prgBanks) * 16384 + (addr & 0x3FFF))
                                  : ((size_t)(m_prgBanks - 1) * 16384 + (addr & 0x3FFF));
            break;
        case 7:
            idx = (size_t)((m_bankSelect & 0x07) % (m_prgBanks / 2 ? m_prgBanks / 2 : 1)) * 32768 + (addr & 0x7FFF);
            break;
        case 1: {
            uint8_t mode = (m_control >> 2) & 3;
            if (mode <= 1) idx = (size_t)((m_prgBank & 0x0E) % m_prgBanks) * 16384 + (addr & 0x7FFF);
            else if (mode == 2) idx = (addr < 0xC000) ? (addr & 0x3FFF)
                                                      : (size_t)(m_prgBank % m_prgBanks) * 16384 + (addr & 0x3FFF);
            else idx = (addr < 0xC000) ? (size_t)(m_prgBank % m_prgBanks) * 16384 + (addr & 0x3FFF)
                                       : (size_t)(m_prgBanks - 1) * 16384 + (addr & 0x3FFF);
            break;
        }
    }
    if (idx >= m_prg.size()) idx %= m_prg.size();
    out = m_prg[idx];
    return true;
}

bool Cart::cpuWrite(uint16_t addr, uint8_t val) {
    if (addr >= 0x6000 && addr <= 0x7FFF) { m_pram[addr & 0x1FFF] = val; return true; }
    if (addr < 0x8000) return false;
    switch (m_mapper) {
        case 2: m_bankSelect = val & 0x0F; return true;
        case 3: m_chrSelect = val & 0x03; return true;
        case 7: m_bankSelect = val; return true;
        case 1: {
            if (val & 0x80) { m_shift = 0x10; m_control |= 0x0C; return true; }
            bool done = (m_shift & 1) != 0;
            m_shift = (uint8_t)((m_shift >> 1) | ((val & 1) << 4));
            if (done) {
                uint8_t reg = (uint8_t)(m_shift & 0x1F);
                uint16_t target = (addr >> 13) & 3;
                if (target == 0) m_control = reg;
                else if (target == 1) m_chr0 = reg;
                else if (target == 2) m_chr1 = reg;
                else m_prgBank = reg & 0x0F;
                m_shift = 0x10;
            }
            return true;
        }
        default: return true;
    }
}

bool Cart::ppuRead(uint16_t addr, uint8_t& out) {
    if (addr > 0x1FFF) return false;
    size_t idx = addr;
    if (m_mapper == 3) idx = (size_t)(m_chrSelect % (m_chr.size() / 8192 ? m_chr.size() / 8192 : 1)) * 8192 + addr;
    else if (m_mapper == 1 && !m_chrRam) {
        size_t banks = m_chr.size() / 4096; if (!banks) banks = 1;
        if (m_control & 0x10) idx = (size_t)((addr < 0x1000 ? m_chr0 : m_chr1) % banks) * 4096 + (addr & 0x0FFF);
        else idx = (size_t)((m_chr0 & 0x1E) % banks) * 4096 + (addr & 0x1FFF);
    }
    if (idx >= m_chr.size()) idx %= m_chr.size();
    out = m_chr[idx];
    return true;
}

bool Cart::ppuWrite(uint16_t addr, uint8_t val) {
    if (addr > 0x1FFF || !m_chrRam) return false;
    m_chr[addr] = val;
    return true;
}
