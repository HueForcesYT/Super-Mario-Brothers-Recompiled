#pragma once
#include <cstdint>
#include <string>
#include "apu.h"
#include "cart.h"
#include "cpu.h"
#include "ppu.h"

// The whole NES: CPU + PPU + APU + RAM + controllers.
class Bus {
public:
    CPU cpu;
    PPU ppu;
    APU apu;
    Cart cart;
    uint8_t ram[2048] = {0};
    uint8_t controller[2] = {0, 0};   // bit7=A, B, Select, Start, Up, Down, Left, bit0=Right

    Bus();
    bool loadRom(const std::string& path, std::string& err);
    void reset();
    void stepFrame();                 // run exactly one video frame
    uint64_t frame() const { return ppu.frameCount; }

    uint8_t cpuRead(uint16_t addr);
    void cpuWrite(uint16_t addr, uint8_t data);

private:
    uint8_t controllerLatch[2] = {0, 0};
    uint64_t systemClock = 0;
    bool dmaActive = false, dmaDummy = true;
    int cpuStall = 0;
    uint8_t dmaPage = 0, dmaAddr = 0, dmaData = 0;
};
