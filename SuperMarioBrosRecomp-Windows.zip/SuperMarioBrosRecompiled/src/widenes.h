#pragma once
#include <cstdint>
#include <vector>
#include "ppu.h"

// Clean-room wideNES-style mapper inspired by the public ANESE design notes:
// sample scroll deltas, retain visited scene pixels, mask HUD padding, and
// detect scene transitions from a perceptual frame signature.
class WideNES {
public:
    static const int CANVAS_W = 3072;
    static const int CANVAS_H = 960;
    std::vector<uint32_t> canvas;
    std::vector<uint8_t> known;
    int camX = 0, camY = 0;
    int padLeft = 0, padRight = 0, padTop = 0, padBottom = 0;
    bool enabled = true;
    uint64_t scenes = 0;

    WideNES();
    void reset();
    void submitFrame(const PPU& ppu);
    void blitViewport(uint32_t* dst, int viewW, int viewH, float zoom, int panX, int panY) const;

private:
    int lastScrollX = -1, lastScrollY = -1;
    uint64_t lastHash = 0;
    std::vector<uint32_t> live;
    void clearCanvas();
    uint64_t perceptualHash(const PPU& ppu) const;
    void detectPadding(const PPU& ppu);
    void beginScene();
};
