#pragma once
#include <cstdint>
#include "cart.h"

// 2C02 PPU: background + sprites, sprite-0 hit, scrolling, NMI.
class PPU {
public:
    Cart* cart = nullptr;
    uint32_t framebuffer[256 * 240] = {0};   // 0xAARRGGBB
    bool frameComplete = false;
    bool nmiRequest = false;
    int scanline = 0, cycle = 0;
    uint64_t frameCount = 0;

    uint8_t oam[256] = {0};
    uint8_t oamAddr = 0;

    void reset();
    void clock();
    uint8_t cpuRead(uint16_t addr, bool readonly = false);
    void cpuWrite(uint16_t addr, uint8_t data);

    // exposed for the wideNES layer
    uint8_t fineX() const { return fine_x; }
    uint8_t coarseScrollX() const { return (uint8_t)((vram.coarse_x << 3) | fine_x); }
    uint8_t scrollYRaw() const { return (uint8_t)((vram.coarse_y << 3) | vram.fine_y); }
    uint8_t nametableX() const { return vram.nametable_x; }
    uint8_t nametableY() const { return vram.nametable_y; }
    uint8_t maskReg() const { return mask.reg; }

    // per-scanline scroll snapshot, used by the wideNES layer to detect split screens (HUDs)
    uint16_t lineScrollX[240] = {0};
    uint16_t lineScrollY[240] = {0};
    bool renderingOn() const { return mask.bg || mask.spr; }

private:
    uint8_t nameTable[2][1024] = {{0}};
    uint8_t paletteRam[32] = {0};
    uint8_t ppuDataBuffer = 0;

    union LoopyReg {
        struct { uint16_t coarse_x : 5, coarse_y : 5, nametable_x : 1, nametable_y : 1, fine_y : 3, unused : 1; };
        uint16_t reg = 0;
    } vram, tram;

    union { struct { uint8_t grayscale:1, bg_left:1, spr_left:1, bg:1, spr:1, r:1, g:1, b:1; }; uint8_t reg = 0; } mask;
    union { struct { uint8_t nt_x:1, nt_y:1, inc:1, spr_pat:1, bg_pat:1, spr_size:1, slave:1, nmi:1; }; uint8_t reg = 0; } ctrl;
    union { struct { uint8_t unused:5, sprite_overflow:1, sprite_zero_hit:1, vblank:1; }; uint8_t reg = 0; } stat;

    uint8_t fine_x = 0;
public:
    uint16_t liveScrollX() const { return (uint16_t)((tram.nametable_x << 8) | (tram.coarse_x << 3) | fine_x); }
    uint16_t liveScrollY() const { return (uint16_t)((tram.nametable_y * 240) + (tram.coarse_y << 3) + tram.fine_y); }
private:
    uint8_t addrLatch = 0;

    uint8_t bgNextTileId = 0, bgNextTileAttr = 0, bgNextTileLo = 0, bgNextTileHi = 0;
    uint16_t bgShifterPatLo = 0, bgShifterPatHi = 0, bgShifterAttrLo = 0, bgShifterAttrHi = 0;

    struct SpriteEntry { uint8_t y, id, attr, x; };
    SpriteEntry lineSprites[8];
    uint8_t lineSpriteCount = 0;
    uint8_t spriteShifterLo[8] = {0}, spriteShifterHi[8] = {0};
    bool spriteZeroPossible = false, spriteZeroRendered = false;

    uint8_t ppuRead(uint16_t addr);
    void ppuWrite(uint16_t addr, uint8_t data);
    void incScrollX();
    void incScrollY();
    void transferAddressX();
    void transferAddressY();
    void loadShifters();
    void updateShifters();
};

extern const uint32_t kNesPalette[64];
