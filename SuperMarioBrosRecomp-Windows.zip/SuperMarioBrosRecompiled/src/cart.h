#pragma once
#include <cstdint>
#include <string>
#include <vector>

enum class Mirror { Horizontal, Vertical, OneScreenLo, OneScreenHi, FourScreen };

// iNES / NES 2.0 cartridge with mappers 0,1,2,3,7 (covers SMB and most early carts).
class Cart {
public:
    bool loadFile(const std::string& path, std::string& err);
    bool loadBytes(const std::vector<uint8_t>& data, std::string& err);
    bool valid() const { return m_valid; }

    bool cpuRead(uint16_t addr, uint8_t& out);
    bool cpuWrite(uint16_t addr, uint8_t val);
    bool ppuRead(uint16_t addr, uint8_t& out);
    bool ppuWrite(uint16_t addr, uint8_t val);

    Mirror mirror() const;
    uint8_t mapperId() const { return m_mapper; }
    const std::string& title() const { return m_title; }
    uint32_t crc32() const { return m_crc; }
    void reset();

private:
    bool m_valid = false;
    uint8_t m_mapper = 0;
    uint8_t m_prgBanks = 0, m_chrBanks = 0;
    Mirror m_mirror = Mirror::Horizontal;
    std::string m_title;
    uint32_t m_crc = 0;
    std::vector<uint8_t> m_prg, m_chr, m_pram;
    bool m_chrRam = false;
    // mapper state
    uint8_t m_bankSelect = 0, m_chrSelect = 0;
    uint8_t m_shift = 0x10, m_control = 0x0C, m_chr0 = 0, m_chr1 = 0, m_prgBank = 0;
};
