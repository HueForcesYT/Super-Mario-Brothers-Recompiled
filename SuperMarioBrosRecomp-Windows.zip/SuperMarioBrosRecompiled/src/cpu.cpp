#include "cpu.h"
#include "bus.h"

enum Mode { IMP, ACC, IMM, ZP0, ZPX, ZPY, REL, ABS, ABX, ABY, IND, IZX, IZY };
enum Op {
    ADC,AND,ASL,BCC,BCS,BEQ,BIT,BMI,BNE,BPL,BRK,BVC,BVS,CLC,CLD,CLI,CLV,CMP,CPX,CPY,
    DEC,DEX,DEY,EOR,INC,INX,INY,JMP,JSR,LDA,LDX,LDY,LSR,NOP,ORA,PHA,PHP,PLA,PLP,ROL,
    ROR,RTI,RTS,SBC,SEC,SED,SEI,STA,STX,STY,TAX,TAY,TSX,TXA,TXS,TYA,
    LAX,SAX,DCP,ISB,SLO,RLA,SRE,RRA,ANC,ALR,ARR,AXS,KIL,XXX
};

static const uint8_t MODES[256] = {
IMP,IZX,IMP,IZX,ZP0,ZP0,ZP0,ZP0,IMP,IMM,ACC,IMM,ABS,ABS,ABS,ABS,
REL,IZY,IMP,IZY,ZPX,ZPX,ZPX,ZPX,IMP,ABY,IMP,ABY,ABX,ABX,ABX,ABX,
ABS,IZX,IMP,IZX,ZP0,ZP0,ZP0,ZP0,IMP,IMM,ACC,IMM,ABS,ABS,ABS,ABS,
REL,IZY,IMP,IZY,ZPX,ZPX,ZPX,ZPX,IMP,ABY,IMP,ABY,ABX,ABX,ABX,ABX,
IMP,IZX,IMP,IZX,ZP0,ZP0,ZP0,ZP0,IMP,IMM,ACC,IMM,ABS,ABS,ABS,ABS,
REL,IZY,IMP,IZY,ZPX,ZPX,ZPX,ZPX,IMP,ABY,IMP,ABY,ABX,ABX,ABX,ABX,
IMP,IZX,IMP,IZX,ZP0,ZP0,ZP0,ZP0,IMP,IMM,ACC,IMM,IND,ABS,ABS,ABS,
REL,IZY,IMP,IZY,ZPX,ZPX,ZPX,ZPX,IMP,ABY,IMP,ABY,ABX,ABX,ABX,ABX,
IMM,IZX,IMM,IZX,ZP0,ZP0,ZP0,ZP0,IMP,IMM,IMP,IMM,ABS,ABS,ABS,ABS,
REL,IZY,IMP,IZY,ZPX,ZPX,ZPY,ZPY,IMP,ABY,IMP,ABY,ABX,ABX,ABY,ABY,
IMM,IZX,IMM,IZX,ZP0,ZP0,ZP0,ZP0,IMP,IMM,IMP,IMM,ABS,ABS,ABS,ABS,
REL,IZY,IMP,IZY,ZPX,ZPX,ZPY,ZPY,IMP,ABY,IMP,ABY,ABX,ABX,ABY,ABY,
IMM,IZX,IMM,IZX,ZP0,ZP0,ZP0,ZP0,IMP,IMM,IMP,IMM,ABS,ABS,ABS,ABS,
REL,IZY,IMP,IZY,ZPX,ZPX,ZPX,ZPX,IMP,ABY,IMP,ABY,ABX,ABX,ABX,ABX,
IMM,IZX,IMM,IZX,ZP0,ZP0,ZP0,ZP0,IMP,IMM,IMP,IMM,ABS,ABS,ABS,ABS,
REL,IZY,IMP,IZY,ZPX,ZPX,ZPX,ZPX,IMP,ABY,IMP,ABY,ABX,ABX,ABX,ABX };

static const uint8_t OPS[256] = {
BRK,ORA,KIL,SLO,NOP,ORA,ASL,SLO,PHP,ORA,ASL,ANC,NOP,ORA,ASL,SLO,
BPL,ORA,KIL,SLO,NOP,ORA,ASL,SLO,CLC,ORA,NOP,SLO,NOP,ORA,ASL,SLO,
JSR,AND,KIL,RLA,BIT,AND,ROL,RLA,PLP,AND,ROL,ANC,BIT,AND,ROL,RLA,
BMI,AND,KIL,RLA,NOP,AND,ROL,RLA,SEC,AND,NOP,RLA,NOP,AND,ROL,RLA,
RTI,EOR,KIL,SRE,NOP,EOR,LSR,SRE,PHA,EOR,LSR,ALR,JMP,EOR,LSR,SRE,
BVC,EOR,KIL,SRE,NOP,EOR,LSR,SRE,CLI,EOR,NOP,SRE,NOP,EOR,LSR,SRE,
RTS,ADC,KIL,RRA,NOP,ADC,ROR,RRA,PLA,ADC,ROR,ARR,JMP,ADC,ROR,RRA,
BVS,ADC,KIL,RRA,NOP,ADC,ROR,RRA,SEI,ADC,NOP,RRA,NOP,ADC,ROR,RRA,
NOP,STA,NOP,SAX,STY,STA,STX,SAX,DEY,NOP,TXA,XXX,STY,STA,STX,SAX,
BCC,STA,KIL,XXX,STY,STA,STX,SAX,TYA,STA,TXS,XXX,XXX,STA,XXX,XXX,
LDY,LDA,LDX,LAX,LDY,LDA,LDX,LAX,TAY,LDA,TAX,LAX,LDY,LDA,LDX,LAX,
BCS,LDA,KIL,LAX,LDY,LDA,LDX,LAX,CLV,LDA,TSX,LAX,LDY,LDA,LDX,LAX,
CPY,CMP,NOP,DCP,CPY,CMP,DEC,DCP,INY,CMP,DEX,AXS,CPY,CMP,DEC,DCP,
BNE,CMP,KIL,DCP,NOP,CMP,DEC,DCP,CLD,CMP,NOP,DCP,NOP,CMP,DEC,DCP,
CPX,SBC,NOP,ISB,CPX,SBC,INC,ISB,INX,SBC,NOP,SBC,CPX,SBC,INC,ISB,
BEQ,SBC,KIL,ISB,NOP,SBC,INC,ISB,SED,SBC,NOP,ISB,NOP,SBC,INC,ISB };

static const uint8_t CYC[256] = {
7,6,2,8,3,3,5,5,3,2,2,2,4,4,6,6, 2,5,2,8,4,4,6,6,2,4,2,7,4,4,7,7,
6,6,2,8,3,3,5,5,4,2,2,2,4,4,6,6, 2,5,2,8,4,4,6,6,2,4,2,7,4,4,7,7,
6,6,2,8,3,3,5,5,3,2,2,2,3,4,6,6, 2,5,2,8,4,4,6,6,2,4,2,7,4,4,7,7,
6,6,2,8,3,3,5,5,4,2,2,2,5,4,6,6, 2,5,2,8,4,4,6,6,2,4,2,7,4,4,7,7,
2,6,2,6,3,3,3,3,2,2,2,2,4,4,4,4, 2,6,2,6,4,4,4,4,2,5,2,5,5,5,5,5,
2,6,2,6,3,3,3,3,2,2,2,2,4,4,4,4, 2,5,2,5,4,4,4,4,2,4,2,4,4,4,4,4,
2,6,2,8,3,3,5,5,2,2,2,2,4,4,6,6, 2,5,2,8,4,4,6,6,2,4,2,7,4,4,7,7,
2,6,2,8,3,3,5,5,2,2,2,2,4,4,6,6, 2,5,2,8,4,4,6,6,2,4,2,7,4,4,7,7 };

// opcodes where crossing a page boundary costs one extra cycle
static bool pageCostly(uint8_t op) {
    switch (op) {
        case 0x11: case 0x19: case 0x1D:
        case 0x31: case 0x39: case 0x3D:
        case 0x51: case 0x59: case 0x5D:
        case 0x71: case 0x79: case 0x7D:
        case 0xB1: case 0xB3: case 0xB9: case 0xBB: case 0xBC: case 0xBD: case 0xBE: case 0xBF:
        case 0xD1: case 0xD9: case 0xDD:
        case 0xF1: case 0xF9: case 0xFD: return true;
        default: return false;
    }
}

uint8_t CPU::read(uint16_t addr) { return bus->cpuRead(addr); }
void CPU::write(uint16_t addr, uint8_t v) { bus->cpuWrite(addr, v); }
void CPU::push(uint8_t v) { write((uint16_t)(0x0100 + sp), v); sp--; }
uint8_t CPU::pop() { sp++; return read((uint16_t)(0x0100 + sp)); }
void CPU::setZN(uint8_t v) { setFlag(F_Z, v == 0); setFlag(F_N, (v & 0x80) != 0); }

void CPU::reset() {
    a = x = y = 0;
    sp = 0xFD;
    status = 0x24;
    pc = (uint16_t)(read(0xFFFC) | (read(0xFFFD) << 8));
    totalCycles = 0;
    irqLine = false;
}

void CPU::nmi() {
    push((uint8_t)(pc >> 8));
    push((uint8_t)(pc & 0xFF));
    push((uint8_t)((status & ~F_B) | F_U));
    setFlag(F_I, true);
    pc = (uint16_t)(read(0xFFFA) | (read(0xFFFB) << 8));
    totalCycles += 7;
}

void CPU::irq() {
    if (flag(F_I)) return;
    push((uint8_t)(pc >> 8));
    push((uint8_t)(pc & 0xFF));
    push((uint8_t)((status & ~F_B) | F_U));
    setFlag(F_I, true);
    pc = (uint16_t)(read(0xFFFE) | (read(0xFFFF) << 8));
    totalCycles += 7;
}

int CPU::step() {
    uint8_t opcode = read(pc++);
    uint8_t mode = MODES[opcode];
    uint8_t op = OPS[opcode];
    int cycles = CYC[opcode];
    uint16_t addr = 0;
    bool crossed = false;
    bool acc = (mode == ACC);

    switch (mode) {
        case IMP: case ACC: break;
        case IMM: addr = pc++; break;
        case ZP0: addr = read(pc++); break;
        case ZPX: addr = (uint8_t)(read(pc++) + x); break;
        case ZPY: addr = (uint8_t)(read(pc++) + y); break;
        case REL: addr = read(pc++); if (addr & 0x80) addr |= 0xFF00; break;
        case ABS: addr = (uint16_t)(read(pc) | (read((uint16_t)(pc + 1)) << 8)); pc += 2; break;
        case ABX: {
            uint16_t base = (uint16_t)(read(pc) | (read((uint16_t)(pc + 1)) << 8)); pc += 2;
            addr = (uint16_t)(base + x);
            crossed = ((base ^ addr) & 0xFF00) != 0;
            break;
        }
        case ABY: {
            uint16_t base = (uint16_t)(read(pc) | (read((uint16_t)(pc + 1)) << 8)); pc += 2;
            addr = (uint16_t)(base + y);
            crossed = ((base ^ addr) & 0xFF00) != 0;
            break;
        }
        case IND: {
            uint16_t ptr = (uint16_t)(read(pc) | (read((uint16_t)(pc + 1)) << 8)); pc += 2;
            uint16_t hi = (uint16_t)((ptr & 0xFF00) | ((ptr + 1) & 0x00FF)); // 6502 page-wrap bug
            addr = (uint16_t)(read(ptr) | (read(hi) << 8));
            break;
        }
        case IZX: {
            uint8_t zp = (uint8_t)(read(pc++) + x);
            addr = (uint16_t)(read(zp) | (read((uint8_t)(zp + 1)) << 8));
            break;
        }
        case IZY: {
            uint8_t zp = read(pc++);
            uint16_t base = (uint16_t)(read(zp) | (read((uint8_t)(zp + 1)) << 8));
            addr = (uint16_t)(base + y);
            crossed = ((base ^ addr) & 0xFF00) != 0;
            break;
        }
    }
    if (crossed && pageCostly(opcode)) cycles++;

    auto M = [&]() -> uint8_t { return read(addr); };
    auto branch = [&](bool take) {
        if (!take) return;
        uint16_t dst = (uint16_t)(pc + addr);
        cycles += ((dst ^ pc) & 0xFF00) ? 2 : 1;
        pc = dst;
    };
    auto doADC = [&](uint8_t v) {
        uint16_t sum = (uint16_t)a + v + (flag(F_C) ? 1 : 0);
        setFlag(F_C, sum > 0xFF);
        setFlag(F_V, (~(a ^ v) & (a ^ (uint8_t)sum) & 0x80) != 0);
        a = (uint8_t)sum;
        setZN(a);
    };
    auto doCMP = [&](uint8_t reg, uint8_t v) {
        setFlag(F_C, reg >= v);
        setZN((uint8_t)(reg - v));
    };

    switch (op) {
        case ADC: doADC(M()); break;
        case SBC: doADC((uint8_t)~M()); break;
        case AND: a &= M(); setZN(a); break;
        case ORA: a |= M(); setZN(a); break;
        case EOR: a ^= M(); setZN(a); break;
        case ASL: { uint8_t v = acc ? a : M(); setFlag(F_C, (v & 0x80) != 0); v = (uint8_t)(v << 1); setZN(v); if (acc) a = v; else write(addr, v); break; }
        case LSR: { uint8_t v = acc ? a : M(); setFlag(F_C, (v & 1) != 0); v = (uint8_t)(v >> 1); setZN(v); if (acc) a = v; else write(addr, v); break; }
        case ROL: { uint8_t v = acc ? a : M(); uint8_t c = flag(F_C) ? 1 : 0; setFlag(F_C, (v & 0x80) != 0); v = (uint8_t)((v << 1) | c); setZN(v); if (acc) a = v; else write(addr, v); break; }
        case ROR: { uint8_t v = acc ? a : M(); uint8_t c = flag(F_C) ? 0x80 : 0; setFlag(F_C, (v & 1) != 0); v = (uint8_t)((v >> 1) | c); setZN(v); if (acc) a = v; else write(addr, v); break; }
        case BIT: { uint8_t v = M(); setFlag(F_Z, (a & v) == 0); setFlag(F_N, (v & 0x80) != 0); setFlag(F_V, (v & 0x40) != 0); break; }
        case BCC: branch(!flag(F_C)); break;
        case BCS: branch(flag(F_C)); break;
        case BEQ: branch(flag(F_Z)); break;
        case BNE: branch(!flag(F_Z)); break;
        case BMI: branch(flag(F_N)); break;
        case BPL: branch(!flag(F_N)); break;
        case BVC: branch(!flag(F_V)); break;
        case BVS: branch(flag(F_V)); break;
        case BRK: {
            pc++;
            push((uint8_t)(pc >> 8)); push((uint8_t)(pc & 0xFF));
            push((uint8_t)(status | F_B | F_U));
            setFlag(F_I, true);
            pc = (uint16_t)(read(0xFFFE) | (read(0xFFFF) << 8));
            break;
        }
        case CLC: setFlag(F_C, false); break;
        case CLD: setFlag(F_D, false); break;
        case CLI: setFlag(F_I, false); break;
        case CLV: setFlag(F_V, false); break;
        case SEC: setFlag(F_C, true); break;
        case SED: setFlag(F_D, true); break;
        case SEI: setFlag(F_I, true); break;
        case CMP: doCMP(a, M()); break;
        case CPX: doCMP(x, M()); break;
        case CPY: doCMP(y, M()); break;
        case DEC: { uint8_t v = (uint8_t)(M() - 1); write(addr, v); setZN(v); break; }
        case INC: { uint8_t v = (uint8_t)(M() + 1); write(addr, v); setZN(v); break; }
        case DEX: x--; setZN(x); break;
        case DEY: y--; setZN(y); break;
        case INX: x++; setZN(x); break;
        case INY: y++; setZN(y); break;
        case JMP: pc = addr; break;
        case JSR: { uint16_t r = (uint16_t)(pc - 1); push((uint8_t)(r >> 8)); push((uint8_t)(r & 0xFF)); pc = addr; break; }
        case RTS: { uint16_t lo = pop(); uint16_t hi = pop(); pc = (uint16_t)(((hi << 8) | lo) + 1); break; }
        case RTI: { status = (uint8_t)((pop() & ~F_B) | F_U); uint16_t lo = pop(); uint16_t hi = pop(); pc = (uint16_t)((hi << 8) | lo); break; }
        case LDA: a = M(); setZN(a); break;
        case LDX: x = M(); setZN(x); break;
        case LDY: y = M(); setZN(y); break;
        case STA: write(addr, a); break;
        case STX: write(addr, x); break;
        case STY: write(addr, y); break;
        case TAX: x = a; setZN(x); break;
        case TAY: y = a; setZN(y); break;
        case TXA: a = x; setZN(a); break;
        case TYA: a = y; setZN(a); break;
        case TSX: x = sp; setZN(x); break;
        case TXS: sp = x; break;
        case PHA: push(a); break;
        case PHP: push((uint8_t)(status | F_B | F_U)); break;
        case PLA: a = pop(); setZN(a); break;
        case PLP: status = (uint8_t)((pop() & ~F_B) | F_U); break;
        case LAX: a = M(); x = a; setZN(a); break;
        case SAX: write(addr, (uint8_t)(a & x)); break;
        case DCP: { uint8_t v = (uint8_t)(M() - 1); write(addr, v); doCMP(a, v); break; }
        case ISB: { uint8_t v = (uint8_t)(M() + 1); write(addr, v); doADC((uint8_t)~v); break; }
        case SLO: { uint8_t v = M(); setFlag(F_C, (v & 0x80) != 0); v = (uint8_t)(v << 1); write(addr, v); a |= v; setZN(a); break; }
        case RLA: { uint8_t v = M(); uint8_t c = flag(F_C) ? 1 : 0; setFlag(F_C, (v & 0x80) != 0); v = (uint8_t)((v << 1) | c); write(addr, v); a &= v; setZN(a); break; }
        case SRE: { uint8_t v = M(); setFlag(F_C, (v & 1) != 0); v = (uint8_t)(v >> 1); write(addr, v); a ^= v; setZN(a); break; }
        case RRA: { uint8_t v = M(); uint8_t c = flag(F_C) ? 0x80 : 0; setFlag(F_C, (v & 1) != 0); v = (uint8_t)((v >> 1) | c); write(addr, v); doADC(v); break; }
        case ANC: a &= M(); setZN(a); setFlag(F_C, (a & 0x80) != 0); break;
        case ALR: a &= M(); setFlag(F_C, (a & 1) != 0); a = (uint8_t)(a >> 1); setZN(a); break;
        case ARR: { a &= M(); uint8_t c = flag(F_C) ? 0x80 : 0; a = (uint8_t)((a >> 1) | c); setZN(a); setFlag(F_C, (a & 0x40) != 0); setFlag(F_V, (((a >> 6) ^ (a >> 5)) & 1) != 0); break; }
        case AXS: { uint8_t v = M(); uint8_t t = (uint8_t)(a & x); setFlag(F_C, t >= v); x = (uint8_t)(t - v); setZN(x); break; }
        case KIL: pc--; break;
        case NOP: case XXX: default: break;
    }

    totalCycles += (uint64_t)cycles;
    return cycles;
}
