// ---------------------------------------------------------------------------
//  Super Mario Bros. Recompiled for PC
//  A native SDL3 front-end around a from-scratch NES machine.
//
//  Pages:  1. LIBRARY  - drop in / browse for your own legal .nes file
//          2. INSTALL  - validate the ROM and install it into your library
//          3. PLAY     - widescreen (wideNES) gameplay
//
//  No ROM, BIOS or game data ships with this program. You supply the dump.
// ---------------------------------------------------------------------------
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>

#include <algorithm>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#include "bus.h"
#include "widenes.h"

static const int NES_W = 256, NES_H = 240;
static const int CLASSIC_W = 320, CLASSIC_H = 240;  // 4:3 display pixels, 256x240 NES pixel aspect corrected
static const int WIDE_W = 426, WIDE_H = 240;      // 16:9 viewport
static const double FRAME_NS = 1000000000.0 / 60.0988;

enum Page { PAGE_LIBRARY, PAGE_INSTALL, PAGE_PLAY };

struct Settings {
    bool widescreen = true;
    bool lowEnd = false;
    bool vsync = true;
    bool audio = true;
    bool integerScale = true;
    float zoom = 1.0f;
};

struct LibraryEntry { std::string name, path; };

enum NesButton { BTN_A, BTN_B, BTN_SELECT, BTN_START, BTN_UP, BTN_DOWN, BTN_LEFT, BTN_RIGHT, BTN_COUNT };

struct App {
    SDL_Window* window = nullptr;
    SDL_Renderer* renderer = nullptr;
    SDL_Texture* screen = nullptr;
    SDL_AudioStream* audio = nullptr;
    SDL_Gamepad* pads[4] = {nullptr, nullptr, nullptr, nullptr};

    Bus nes;
    WideNES wide;
    Settings cfg;
    Page page = PAGE_LIBRARY;

    std::string libraryDir;
    std::vector<LibraryEntry> library;
    int selected = 0;

    std::string pendingPath, pendingError, statusLine;
    bool pendingValid = false;
    uint32_t pendingCrc = 0;
    int pendingMapper = 0;
    size_t pendingSize = 0;
    float installProgress = -1.0f;

    std::vector<uint32_t> viewport;
    int screenW = 0, screenH = 0;
    bool fillScreen = false;
    bool fullscreen = false;
    bool running = true;
    bool showHelp = false;
    int panX = 0, panY = 0;
    int skippedFrames = 0;
    float fps = 0.0f;
    SDL_Scancode bindings[BTN_COUNT] = {
        SDL_SCANCODE_X, SDL_SCANCODE_Z, SDL_SCANCODE_RSHIFT, SDL_SCANCODE_RETURN,
        SDL_SCANCODE_UP, SDL_SCANCODE_DOWN, SDL_SCANCODE_LEFT, SDL_SCANCODE_RIGHT
    };
    int remapButton = -1;
    bool remapListening = false;
};

// ------------------------------------------------------------------ drawing
static void drawText(SDL_Renderer* r, float x, float y, float scale, SDL_Color c, const char* fmt, ...) {
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    SDL_vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    SDL_SetRenderScale(r, scale, scale);
    SDL_SetRenderDrawColor(r, c.r, c.g, c.b, c.a);
    SDL_RenderDebugText(r, x / scale, y / scale, buf);
    SDL_SetRenderScale(r, 1.0f, 1.0f);
}

static void fillRect(SDL_Renderer* r, float x, float y, float w, float h, SDL_Color c) {
    SDL_FRect rect{x, y, w, h};
    SDL_SetRenderDrawColor(r, c.r, c.g, c.b, c.a);
    SDL_RenderFillRect(r, &rect);
}

static void outlineRect(SDL_Renderer* r, float x, float y, float w, float h, SDL_Color c) {
    SDL_FRect rect{x, y, w, h};
    SDL_SetRenderDrawColor(r, c.r, c.g, c.b, c.a);
    SDL_RenderRect(r, &rect);
}

static const SDL_Color WHITE{235, 238, 245, 255};
static const SDL_Color DIM{140, 148, 165, 255};
static const SDL_Color ACCENT{255, 196, 62, 255};
static const SDL_Color GOOD{104, 214, 132, 255};
static const SDL_Color BAD{240, 106, 106, 255};

// ------------------------------------------------------------------ library
static std::string joinPath(const std::string& a, const std::string& b) {
    if (a.empty()) return b;
    char last = a[a.size() - 1];
    if (last == '/' || last == '\\') return a + b;
    return a + "/" + b;
}

static void scanLibrary(App& app) {
    app.library.clear();
    int count = 0;
    char** files = SDL_GlobDirectory(app.libraryDir.c_str(), "*.nes", SDL_GLOB_CASEINSENSITIVE, &count);
    if (files) {
        for (int i = 0; i < count; i++) {
            LibraryEntry e;
            e.name = files[i];
            e.path = joinPath(app.libraryDir, files[i]);
            app.library.push_back(e);
        }
        SDL_free(files);
    }
    // also pick up a roms/ folder sitting next to the exe
    const char* base = SDL_GetBasePath();
    if (base) {
        std::string roms = joinPath(base, "roms");
        count = 0;
        files = SDL_GlobDirectory(roms.c_str(), "*.nes", SDL_GLOB_CASEINSENSITIVE, &count);
        if (files) {
            for (int i = 0; i < count; i++) {
                LibraryEntry e;
                e.name = std::string(files[i]) + "  (roms folder)";
                e.path = joinPath(roms, files[i]);
                app.library.push_back(e);
            }
            SDL_free(files);
        }
    }
    if (app.selected >= (int)app.library.size()) app.selected = 0;
}

static void inspectRom(App& app, const std::string& path) {
    app.pendingPath = path;
    app.pendingError.clear();
    app.pendingValid = false;
    app.installProgress = -1.0f;

    size_t sz = 0;
    void* data = SDL_LoadFile(path.c_str(), &sz);
    if (!data) { app.pendingError = "Could not read that file."; app.page = PAGE_INSTALL; return; }
    std::vector<uint8_t> bytes((uint8_t*)data, (uint8_t*)data + sz);
    SDL_free(data);

    Cart probe;
    std::string err;
    if (!probe.loadBytes(bytes, err)) { app.pendingError = err; app.page = PAGE_INSTALL; return; }

    app.pendingValid = true;
    app.pendingCrc = probe.crc32();
    app.pendingMapper = probe.mapperId();
    app.pendingSize = sz;
    app.page = PAGE_INSTALL;
}

static bool installPending(App& app) {
    size_t sz = 0;
    void* data = SDL_LoadFile(app.pendingPath.c_str(), &sz);
    if (!data) { app.pendingError = "Install failed: source file vanished."; return false; }
    std::string base = app.pendingPath;
    size_t slash = base.find_last_of("/\\");
    if (slash != std::string::npos) base = base.substr(slash + 1);
    std::string dst = joinPath(app.libraryDir, base);
    bool ok = SDL_SaveFile(dst.c_str(), data, sz);
    SDL_free(data);
    if (!ok) { app.pendingError = std::string("Install failed: ") + SDL_GetError(); return false; }

    char manifest[512];
    SDL_snprintf(manifest, sizeof(manifest),
        "title=%s\nmapper=%d\ncrc32=%08X\nbytes=%zu\nsource=user supplied dump\n",
        base.c_str(), app.pendingMapper, app.pendingCrc, sz);
    std::string mpath = dst + ".info";
    SDL_SaveFile(mpath.c_str(), manifest, SDL_strlen(manifest));

    app.pendingPath = dst;
    scanLibrary(app);
    for (size_t i = 0; i < app.library.size(); i++) if (app.library[i].path == dst) app.selected = (int)i;
    return true;
}

static bool bootGame(App& app, const std::string& path) {
    std::string err;
    if (!app.nes.loadRom(path, err)) { app.pendingError = err; app.page = PAGE_INSTALL; return false; }
    app.nes.apu.setSampleRate(44100);
    app.wide.reset();
    app.panX = app.panY = 0;
    app.page = PAGE_PLAY;
    app.statusLine = "Running: " + app.nes.cart.title();
    if (app.audio) SDL_ClearAudioStream(app.audio);
    return true;
}


static const char* buttonName(int b) {
    static const char* names[BTN_COUNT] = {"A", "B", "Select", "Start", "Up", "Down", "Left", "Right"};
    return (b >= 0 && b < BTN_COUNT) ? names[b] : "";
}

static void renderRemapOverlay(App& app, int w, int h) {
    fillRect(app.renderer, 0, 0, (float)w, (float)h, SDL_Color{8, 10, 16, 245});
    fillRect(app.renderer, 30, 30, w - 60.0f, h - 60.0f, SDL_Color{22, 27, 39, 255});
    outlineRect(app.renderer, 30, 30, w - 60.0f, h - 60.0f, SDL_Color{86, 103, 140, 255});
    drawText(app.renderer, 62, 64, 2.5f, ACCENT, "REMAP CONTROLS");
    drawText(app.renderer, 62, 102, 1.5f, DIM, "Press one keyboard key for each action. ESC cancels.");
    float y = 150;
    for (int i = 0; i < BTN_COUNT; i++) {
        bool current = i == app.remapButton;
        drawText(app.renderer, 90, y, 1.75f, current ? ACCENT : WHITE, "%s", buttonName(i));
        drawText(app.renderer, 270, y, 1.75f, current ? ACCENT : DIM, current ? "< press a key now >" : "mapped");
        y += 28;
    }
    if (app.remapButton < 0) drawText(app.renderer, 62, h - 90.0f, 1.5f, GOOD, "Done. Press F10 to remap again.");
    else drawText(app.renderer, 62, h - 90.0f, 1.5f, ACCENT, "Waiting for %s...", buttonName(app.remapButton));
    drawText(app.renderer, 62, h - 58.0f, 1.5f, DIM, "F10 closes this screen   ESC cancels");
}

// ------------------------------------------------------------------- input
static void openGamepads(App& app) {
    int count = 0;
    SDL_JoystickID* ids = SDL_GetGamepads(&count);
    if (!ids) return;
    for (int i = 0; i < count && i < 4; i++) {
        if (!app.pads[i]) app.pads[i] = SDL_OpenGamepad(ids[i]);
    }
    SDL_free(ids);
}

enum : uint8_t { NES_A = 0x80, NES_B = 0x40, NES_SELECT = 0x20, NES_START = 0x10,
                 NES_UP = 0x08, NES_DOWN = 0x04, NES_LEFT = 0x02, NES_RIGHT = 0x01 };

static uint8_t pollController(App& app, int player) {
    uint8_t s = 0;
    if (player == 0) {
        const bool* k = SDL_GetKeyboardState(nullptr);
        if (k[app.bindings[BTN_A]]) s |= 0x80;
        if (k[app.bindings[BTN_B]]) s |= 0x40;
        if (k[app.bindings[BTN_SELECT]]) s |= 0x20;
        if (k[app.bindings[BTN_START]]) s |= 0x10;
        if (k[app.bindings[BTN_UP]]) s |= 0x08;
        if (k[app.bindings[BTN_DOWN]]) s |= 0x04;
        if (k[app.bindings[BTN_LEFT]]) s |= 0x02;
        if (k[app.bindings[BTN_RIGHT]]) s |= 0x01;
    }
    SDL_Gamepad* gp = app.pads[player];
    if (gp) {
        if (SDL_GetGamepadButton(gp, SDL_GAMEPAD_BUTTON_SOUTH) || SDL_GetGamepadButton(gp, SDL_GAMEPAD_BUTTON_EAST)) s |= 0x80;
        if (SDL_GetGamepadButton(gp, SDL_GAMEPAD_BUTTON_WEST) || SDL_GetGamepadButton(gp, SDL_GAMEPAD_BUTTON_NORTH)) s |= 0x40;
        if (SDL_GetGamepadButton(gp, SDL_GAMEPAD_BUTTON_BACK)) s |= 0x20;
        if (SDL_GetGamepadButton(gp, SDL_GAMEPAD_BUTTON_START)) s |= 0x10;
        if (SDL_GetGamepadButton(gp, SDL_GAMEPAD_BUTTON_DPAD_UP)) s |= 0x08;
        if (SDL_GetGamepadButton(gp, SDL_GAMEPAD_BUTTON_DPAD_DOWN)) s |= 0x04;
        if (SDL_GetGamepadButton(gp, SDL_GAMEPAD_BUTTON_DPAD_LEFT)) s |= 0x02;
        if (SDL_GetGamepadButton(gp, SDL_GAMEPAD_BUTTON_DPAD_RIGHT)) s |= 0x01;
        const int DEAD = 12000;
        int ax = SDL_GetGamepadAxis(gp, SDL_GAMEPAD_AXIS_LEFTX), ay = SDL_GetGamepadAxis(gp, SDL_GAMEPAD_AXIS_LEFTY);
        if (ax < -DEAD) s |= 0x02; if (ax > DEAD) s |= 0x01;
        if (ay < -DEAD) s |= 0x08; if (ay > DEAD) s |= 0x04;
    }
    return s;
}

// -------------------------------------------------------------- file dialog
static void SDLCALL onFilePicked(void* userdata, const char* const* files, int) {
    App* app = (App*)userdata;
    if (files && files[0]) inspectRom(*app, files[0]);
}

static void askForRom(App& app) {
    static const SDL_DialogFileFilter filters[] = {
        { "NES ROM (.nes)", "nes" },
        { "All files", "*" }
    };
    SDL_ShowOpenFileDialog(onFilePicked, &app, app.window, filters, 2, nullptr, false);
}

// ------------------------------------------------------------------- pages
static void renderLibrary(App& app, int w, int h) {
    fillRect(app.renderer, 0, 0, (float)w, (float)h, SDL_Color{14, 16, 22, 255});
    fillRect(app.renderer, 0, 0, (float)w, 74, SDL_Color{24, 28, 40, 255});
    drawText(app.renderer, 28, 20, 3.0f, ACCENT, "SUPER MARIO BROS. RECOMPILED");
    drawText(app.renderer, 30, 48, 1.5f, DIM, "STEP 1 OF 3  -  ADD YOUR OWN LEGAL .NES DUMP");

    fillRect(app.renderer, 28, 100, w - 56.0f, 96, SDL_Color{22, 26, 36, 255});
    outlineRect(app.renderer, 28, 100, w - 56.0f, 96, SDL_Color{70, 80, 105, 255});
    drawText(app.renderer, 48, 126, 2.0f, WHITE, "DRAG A .NES FILE ONTO THIS WINDOW");
    drawText(app.renderer, 48, 156, 1.5f, DIM, "...or press O to browse. Nothing is downloaded, ever.");

    drawText(app.renderer, 28, 224, 1.75f, WHITE, "INSTALLED GAMES");
    float y = 254;
    if (app.library.empty()) {
        drawText(app.renderer, 40, y, 1.5f, DIM, "Library is empty. Add a ROM you legally own to get started.");
    } else {
        for (size_t i = 0; i < app.library.size() && i < 12; i++) {
            bool sel = (int)i == app.selected;
            if (sel) fillRect(app.renderer, 32, y - 6, w - 64.0f, 26, SDL_Color{44, 54, 78, 255});
            drawText(app.renderer, 44, y, 1.5f, sel ? ACCENT : WHITE, "%s %s", sel ? ">" : " ", app.library[i].name.c_str());
            y += 28;
        }
        drawText(app.renderer, 40, y + 12, 1.5f, DIM, "UP/DOWN to choose  -  ENTER to play");
    }

    drawText(app.renderer, 28, h - 62.0f, 1.5f, DIM,
             "O browse   ENTER play   TAB settings   ESC quit");
    drawText(app.renderer, 28, h - 38.0f, 1.5f, SDL_Color{110, 118, 135, 255},
             "This program contains no game data. Use only dumps of cartridges you own.");
}

static void renderInstall(App& app, int w, int h) {
    fillRect(app.renderer, 0, 0, (float)w, (float)h, SDL_Color{14, 16, 22, 255});
    fillRect(app.renderer, 0, 0, (float)w, 74, SDL_Color{24, 28, 40, 255});
    drawText(app.renderer, 28, 20, 3.0f, ACCENT, "INSTALL");
    drawText(app.renderer, 30, 48, 1.5f, DIM, "STEP 2 OF 3  -  VERIFY AND INSTALL");

    std::string shortName = app.pendingPath;
    size_t slash = shortName.find_last_of("/\\");
    if (slash != std::string::npos) shortName = shortName.substr(slash + 1);

    float y = 116;
    drawText(app.renderer, 32, y, 1.75f, WHITE, "FILE: %s", shortName.c_str()); y += 34;

    if (!app.pendingError.empty()) {
        drawText(app.renderer, 32, y, 1.75f, BAD, "REJECTED"); y += 30;
        drawText(app.renderer, 32, y, 1.5f, WHITE, "%s", app.pendingError.c_str()); y += 40;
        drawText(app.renderer, 32, y, 1.5f, DIM, "BACKSPACE to go back and pick another file.");
        return;
    }

    drawText(app.renderer, 32, y, 1.5f, GOOD, "Valid iNES image"); y += 26;
    drawText(app.renderer, 32, y, 1.5f, WHITE, "Mapper : %d", app.pendingMapper); y += 24;
    drawText(app.renderer, 32, y, 1.5f, WHITE, "CRC32  : %08X", app.pendingCrc); y += 24;
    drawText(app.renderer, 32, y, 1.5f, WHITE, "Size   : %zu bytes", app.pendingSize); y += 40;

    if (app.installProgress >= 0.0f) {
        fillRect(app.renderer, 32, y, w - 64.0f, 22, SDL_Color{30, 34, 46, 255});
        fillRect(app.renderer, 32, y, (w - 64.0f) * app.installProgress, 22, ACCENT);
        outlineRect(app.renderer, 32, y, w - 64.0f, 22, SDL_Color{70, 80, 105, 255});
        y += 38;
        drawText(app.renderer, 32, y, 1.5f, app.installProgress >= 1.0f ? GOOD : DIM,
                 app.installProgress >= 1.0f ? "Installed. Press ENTER to play." : "Installing...");
    } else {
        drawText(app.renderer, 32, y, 1.75f, ACCENT, "PRESS I TO INSTALL"); y += 30;
        drawText(app.renderer, 32, y, 1.5f, DIM, "or ENTER to run it straight from where it is");
    }
    drawText(app.renderer, 28, h - 38.0f, 1.5f, DIM, "BACKSPACE back   ESC quit");
}

static void renderPlay(App& app, int w, int h) {
    // The raw NES framebuffer is 256:240, not a display aspect ratio.
    // Correct its 8:7 pixel aspect to 4:3 when wideNES is off.
    int vw = app.cfg.widescreen ? WIDE_W : CLASSIC_W;
    int vh = app.cfg.widescreen ? WIDE_H : CLASSIC_H;

    if ((int)app.viewport.size() != vw * vh) app.viewport.assign((size_t)vw * vh, 0xFF000000);

    if (app.cfg.widescreen) {
        app.wide.blitViewport(app.viewport.data(), vw, vh, app.cfg.zoom, app.panX, app.panY);
        // Do not overlay a 4:3 rectangle here. The virtual 16:9 viewport is
        // already the complete game image, like a PC widescreen remaster.
        // Its side pixels come from the scene cache when available, otherwise
        // from the current frame projection until the player explores them.
    } else {
        // 256x240 NES pixels -> 320x240 4:3 display surface.
        // Do this before SDL scales the window so the classic mode is genuinely 4:3.
        for (int y = 0; y < CLASSIC_H; y++) {
            for (int x = 0; x < CLASSIC_W; x++) {
                int sx = x * NES_W / CLASSIC_W;
                app.viewport[(size_t)y * CLASSIC_W + x] = app.nes.ppu.framebuffer[y * NES_W + sx];
            }
        }
    }

    if (!app.screen || app.screenW != vw || app.screenH != vh) {
        if (app.screen) SDL_DestroyTexture(app.screen);
        app.screen = SDL_CreateTexture(app.renderer, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, vw, vh);
        SDL_SetTextureScaleMode(app.screen, SDL_SCALEMODE_NEAREST);
        app.screenW = vw;
        app.screenH = vh;
    }
    SDL_UpdateTexture(app.screen, nullptr, app.viewport.data(), vw * 4);

    fillRect(app.renderer, 0, 0, (float)w, (float)h, SDL_Color{0, 0, 0, 255});
    float scale = std::min((float)w / vw, (float)h / vh);
    if (app.cfg.integerScale && scale > 1.0f) scale = (float)(int)scale;
    float dw = vw * scale, dh = vh * scale;
    // F9 means actual fill-screen: every output pixel is used, with no bars.
    if (app.fillScreen) { dw = (float)w; dh = (float)h; }
    SDL_FRect dst{(w - dw) * 0.5f, (h - dh) * 0.5f, dw, dh};
    SDL_RenderTexture(app.renderer, app.screen, nullptr, &dst);

    if (app.showHelp) {
        fillRect(app.renderer, 20, 20, 470, 232, SDL_Color{10, 12, 18, 230});
        outlineRect(app.renderer, 20, 20, 470, 232, SDL_Color{80, 90, 115, 255});
        float y = 36;
        drawText(app.renderer, 34, y, 1.75f, ACCENT, "SETTINGS / CONTROLS"); y += 32;
        drawText(app.renderer, 34, y, 1.5f, WHITE, "F1  Remastered wideNES   : %s  [%s]", app.cfg.widescreen ? "ON" : "OFF", app.cfg.widescreen ? "16:9" : "4:3"); y += 22;
        drawText(app.renderer, 34, y, 1.5f, WHITE, "F2  Low-end mode         : %s", app.cfg.lowEnd ? "ON" : "OFF"); y += 22;
        drawText(app.renderer, 34, y, 1.5f, WHITE, "F3  Sound                : %s", app.cfg.audio ? "ON" : "OFF"); y += 22;
        drawText(app.renderer, 34, y, 1.5f, WHITE, "F4  Integer scaling      : %s", app.cfg.integerScale ? "ON" : "OFF"); y += 22;
        drawText(app.renderer, 34, y, 1.5f, WHITE, "F9 fill screen   F10 remap   F11 fullscreen   +/- zoom   IJKL pan   R reset   L library"); y += 22;
        drawText(app.renderer, 34, y, 1.5f, DIM, "Keys: arrows/WASD move, Z=B, X=A, ENTER=start, SHIFT=select"); y += 22;
        drawText(app.renderer, 34, y, 1.5f, DIM, "Pads: hot-plug, A/B face buttons, dpad or left stick"); y += 22;
        drawText(app.renderer, 34, y, 1.5f, DIM, "%.0f fps  -  %d frames skipped  -  %llu maps  -  display %s", app.fps,
                 app.skippedFrames, (unsigned long long)app.wide.scenes, app.cfg.widescreen ? "16:9" : "4:3");
    } else {
        drawText(app.renderer, 12, (float)h - 26, 1.25f, SDL_Color{150, 155, 170, 200},
                 "F9 fill screen: no bars   F10 remap   F11 fullscreen   F1 wideNES: 16:9 / off: 4:3   TAB settings   L library   R reset   %.0f fps", app.fps);
    }
}

// -------------------------------------------------------------------- main
int main(int argc, char* argv[]) {
    if (!SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_GAMEPAD)) {
        SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "Startup failed", SDL_GetError(), nullptr);
        return 1;
    }

    App app;

    // Auto-detect weak hardware so the default experience is smooth on old laptops.
    int cores = SDL_GetNumLogicalCPUCores();
    int ram = SDL_GetSystemRAM();
    if (cores <= 2 || ram <= 2048) { app.cfg.lowEnd = true; app.cfg.widescreen = false; }

    int winW = 1024, winH = 600;
    if (app.cfg.lowEnd) { winW = 768; winH = 480; }

    if (!SDL_CreateWindowAndRenderer("Super Mario Bros. Recompiled", winW, winH,
                                     SDL_WINDOW_RESIZABLE, &app.window, &app.renderer)) {
        SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "Window failed", SDL_GetError(), nullptr);
        return 1;
    }
    SDL_SetRenderVSync(app.renderer, app.cfg.vsync ? 1 : 0);

    SDL_AudioSpec spec;
    SDL_zero(spec);
    spec.format = SDL_AUDIO_F32;
    spec.channels = 1;
    spec.freq = 44100;
    app.audio = SDL_OpenAudioDeviceStream(SDL_AUDIO_DEVICE_DEFAULT_PLAYBACK, &spec, nullptr, nullptr);
    if (app.audio) SDL_ResumeAudioStreamDevice(app.audio);
    app.nes.apu.setSampleRate(44100);

    char* pref = SDL_GetPrefPath("SuperMarioBrosRecompiled", "library");
    app.libraryDir = pref ? pref : "library";
    if (pref) SDL_free(pref);
    SDL_CreateDirectory(app.libraryDir.c_str());
    scanLibrary(app);
    openGamepads(app);

    if (argc > 1) inspectRom(app, argv[1]);

    uint64_t next = SDL_GetTicksNS();
    uint64_t fpsTimer = SDL_GetTicksNS();
    int framesThisSecond = 0;
    std::vector<float> mixbuf(4096);

    while (app.running) {
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            switch (e.type) {
                case SDL_EVENT_QUIT: app.running = false; break;
                case SDL_EVENT_GAMEPAD_ADDED: openGamepads(app); break;
                case SDL_EVENT_GAMEPAD_REMOVED:
                    for (int i = 0; i < 4; i++) {
                        if (app.pads[i] && SDL_GetGamepadID(app.pads[i]) == e.gdevice.which) {
                            SDL_CloseGamepad(app.pads[i]);
                            app.pads[i] = nullptr;
                        }
                    }
                    break;
                case SDL_EVENT_DROP_FILE:
                    if (e.drop.data) inspectRom(app, e.drop.data);
                    break;
                case SDL_EVENT_KEY_DOWN: {
                    SDL_Keycode k = e.key.key;
                    if (k == SDLK_ESCAPE) {
                        if (app.remapListening) { app.remapListening = false; app.remapButton = -1; break; }
                        app.running = false; break;
                    }
                    if (k == SDLK_F10) {
                        app.remapListening = !app.remapListening;
                        app.remapButton = app.remapListening ? 0 : -1;
                        break;
                    }
                    if (app.remapListening) {
                        if (app.remapButton >= 0 && e.key.scancode != SDL_SCANCODE_ESCAPE) {
                            app.bindings[app.remapButton] = e.key.scancode;
                            app.remapButton++;
                            if (app.remapButton >= BTN_COUNT) app.remapButton = -1;
                        }
                        break;
                    }
                    if (k == SDLK_F11) {
                        app.fullscreen = !app.fullscreen;
                        SDL_SetWindowFullscreen(app.window, app.fullscreen);
                        break;
                    }
                    if (k == SDLK_F9) {
                        app.fillScreen = !app.fillScreen;
                        app.fullscreen = app.fillScreen;
                        SDL_SetWindowFullscreen(app.window, app.fullscreen);
                        break;
                    }
                    if (k == SDLK_TAB) { app.showHelp = !app.showHelp; break; }
                    if (k == SDLK_F1) { app.cfg.widescreen = !app.cfg.widescreen; break; }
                    if (k == SDLK_F2) {
                        app.cfg.lowEnd = !app.cfg.lowEnd;
                        if (app.cfg.lowEnd) app.cfg.widescreen = false;
                        break;
                    }
                    if (k == SDLK_F3) { app.cfg.audio = !app.cfg.audio; app.nes.apu.setEnabled(app.cfg.audio); break; }
                    if (k == SDLK_F4) { app.cfg.integerScale = !app.cfg.integerScale; break; }

                    if (app.page == PAGE_LIBRARY) {
                        if (k == SDLK_O) askForRom(app);
                        else if (k == SDLK_UP && app.selected > 0) app.selected--;
                        else if (k == SDLK_DOWN && app.selected + 1 < (int)app.library.size()) app.selected++;
                        else if (k == SDLK_RETURN && !app.library.empty()) bootGame(app, app.library[app.selected].path);
                    } else if (app.page == PAGE_INSTALL) {
                        if (k == SDLK_BACKSPACE) { app.page = PAGE_LIBRARY; scanLibrary(app); }
                        else if (k == SDLK_I && app.pendingValid && app.installProgress < 0.0f) app.installProgress = 0.0f;
                        else if (k == SDLK_RETURN && app.pendingValid) bootGame(app, app.pendingPath);
                    } else if (app.page == PAGE_PLAY) {
                        if (k == SDLK_R) { app.nes.reset(); app.wide.reset(); }
                        else if (k == SDLK_L) { app.page = PAGE_LIBRARY; scanLibrary(app); }
                        else if (k == SDLK_EQUALS || k == SDLK_KP_PLUS) app.cfg.zoom = std::min(3.0f, app.cfg.zoom + 0.1f);
                        else if (k == SDLK_MINUS || k == SDLK_KP_MINUS) app.cfg.zoom = std::max(0.4f, app.cfg.zoom - 0.1f);
                        else if (k == SDLK_I) app.panY -= 8;
                        else if (k == SDLK_K) app.panY += 8;
                        else if (k == SDLK_J) app.panX -= 8;
                        else if (k == SDLK_SEMICOLON) app.panX += 8;
                    }
                    break;
                }
                default: break;
            }
        }

        // fake-free install progress: real copy happens on the first tick
        if (app.page == PAGE_INSTALL && app.installProgress >= 0.0f && app.installProgress < 1.0f) {
            if (app.installProgress == 0.0f) {
                if (!installPending(app)) app.installProgress = -1.0f;
                else app.installProgress = 0.05f;
            } else {
                app.installProgress = std::min(1.0f, app.installProgress + 0.06f);
            }
        }

        bool behind = false;
        if (app.page == PAGE_PLAY && app.nes.cart.valid()) {
            app.nes.controller[0] = pollController(app, 0);
            app.nes.controller[1] = pollController(app, 1);
            app.nes.stepFrame();
            if (app.cfg.widescreen) app.wide.submitFrame(app.nes.ppu);

            if (app.audio && app.cfg.audio) {
                size_t have = app.nes.apu.available();
                if (have > 0) {
                    size_t n = std::min(have, mixbuf.size());
                    app.nes.apu.drain(mixbuf.data(), n);
                    // do not let latency pile up on slow machines
                    if (SDL_GetAudioStreamQueued(app.audio) < 16384)
                        SDL_PutAudioStreamData(app.audio, mixbuf.data(), (int)(n * sizeof(float)));
                }
            }
            behind = (SDL_GetTicksNS() > next + (uint64_t)(FRAME_NS * 2));
        }

        // On very weak hardware, drop the presentation, never the emulation.
        bool drawThisFrame = !(app.cfg.lowEnd && behind);
        if (drawThisFrame) {
            int w = 0, h = 0;
            SDL_GetRenderOutputSize(app.renderer, &w, &h);
            SDL_SetRenderDrawBlendMode(app.renderer, SDL_BLENDMODE_BLEND);
            SDL_SetRenderDrawColor(app.renderer, 14, 16, 22, 255);
            SDL_RenderClear(app.renderer);
            if (app.page == PAGE_LIBRARY) renderLibrary(app, w, h);
            else if (app.page == PAGE_INSTALL) renderInstall(app, w, h);
            else renderPlay(app, w, h);
            if (app.remapListening) renderRemapOverlay(app, w, h);
            SDL_RenderPresent(app.renderer);
        } else {
            app.skippedFrames++;
        }

        framesThisSecond++;
        uint64_t now = SDL_GetTicksNS();
        if (now - fpsTimer >= 1000000000ULL) {
            app.fps = (float)framesThisSecond;
            framesThisSecond = 0;
            fpsTimer = now;
        }

        next += (uint64_t)FRAME_NS;
        if (now < next) SDL_DelayNS(next - now);
        else if (now > next + (uint64_t)(FRAME_NS * 8)) next = now;   // resync after a stall
    }

    for (int i = 0; i < 4; i++) if (app.pads[i]) SDL_CloseGamepad(app.pads[i]);
    if (app.screen) SDL_DestroyTexture(app.screen);
    if (app.audio) SDL_DestroyAudioStream(app.audio);
    SDL_DestroyRenderer(app.renderer);
    SDL_DestroyWindow(app.window);
    SDL_Quit();
    return 0;
}
