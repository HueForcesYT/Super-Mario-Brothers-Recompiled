// Headless self-test: builds a tiny legal homebrew ROM in memory, boots it,
// runs frames, and verifies CPU/PPU/APU wiring. No copyrighted data involved.
#include "../src/bus.h"
#include <cstdio>
#include <cstring>
#include <vector>

static std::vector<uint8_t> makeTestRom() {
    std::vector<uint8_t> rom(16 + 16384 + 8192, 0);
    const char hdr[8] = {'N','E','S',0x1A, 1, 1, 0, 0};
    memcpy(rom.data(), hdr, 8);
    uint8_t* prg = rom.data() + 16;
    // program: enable rendering, write a palette, spin forever
    const uint8_t code[] = {
        0x78,                   // SEI
        0xA9, 0x3F, 0x8D, 0x06, 0x20,   // LDA #$3F ; STA $2006
        0xA9, 0x00, 0x8D, 0x06, 0x20,   // LDA #$00 ; STA $2006
        0xA9, 0x21, 0x8D, 0x07, 0x20,   // LDA #$21 ; STA $2007  (bg colour)
        0xA9, 0x1E, 0x8D, 0x01, 0x20,   // LDA #$1E ; STA $2001  (rendering on)
        0xA9, 0x0F, 0x8D, 0x15, 0x40,   // LDA #$0F ; STA $4015  (APU channels on)
        0xA9, 0x88, 0x8D, 0x02, 0x40,   // pulse1 period lo
        0xA9, 0x08, 0x8D, 0x03, 0x40,   // pulse1 length/hi
        0xA9, 0xBF, 0x8D, 0x00, 0x40,   // pulse1 duty+volume
        0xE8,                   // INX
        0xC8,                   // INY
        0x4C, 0x22, 0x80        // JMP $8022 (loop)
    };
    memcpy(prg, code, sizeof(code));
    prg[0x3FFC] = 0x00; prg[0x3FFD] = 0x80;  // reset vector -> $8000
    return rom;
}

int main() {
    Bus nes;
    std::string err;
    auto rom = makeTestRom();
    if (!nes.cart.loadBytes(rom, err)) { printf("FAIL cart: %s\n", err.c_str()); return 1; }
    nes.reset();
    int fails = 0;

    for (int i = 0; i < 12; i++) nes.stepFrame();

    printf("frames rendered : %llu\n", (unsigned long long)nes.ppu.frameCount);
    printf("cpu cycles      : %llu\n", (unsigned long long)nes.cpu.totalCycles);
    printf("audio samples   : %zu\n", nes.apu.available());

    if (nes.ppu.frameCount < 12) { printf("FAIL: frame counter\n"); fails++; }
    // ~29780 CPU cycles per NTSC frame
    double perFrame = (double)nes.cpu.totalCycles / (double)nes.ppu.frameCount;
    printf("cpu cycles/frame: %.0f (expect ~29780)\n", perFrame);
    if (perFrame < 29000 || perFrame > 30500) { printf("FAIL: cpu/ppu timing ratio\n"); fails++; }
    if (nes.apu.available() < 5000) { printf("FAIL: apu produced no audio\n"); fails++; }

    bool painted = false;
    for (int i = 0; i < 256 * 240; i++) if (nes.ppu.framebuffer[i] != 0 && nes.ppu.framebuffer[i] != 0xFF000000) { painted = true; break; }
    if (!painted) { printf("FAIL: framebuffer never painted\n"); fails++; }
    else printf("framebuffer     : painted, top-left = 0x%08X\n", nes.ppu.framebuffer[0]);

    // controller shift register round-trip
    nes.controller[0] = 0x81;
    nes.cpuWrite(0x4016, 1);
    uint8_t bits = 0;
    for (int i = 0; i < 8; i++) bits = (uint8_t)((bits << 1) | (nes.cpuRead(0x4016) & 1));
    printf("controller latch: 0x%02X (expect 0x81)\n", bits);
    if (bits != 0x81) { printf("FAIL: controller\n"); fails++; }

    printf(fails ? "\nSELFTEST FAILED (%d)\n" : "\nSELFTEST PASSED\n", fails);
    return fails ? 1 : 0;
}
