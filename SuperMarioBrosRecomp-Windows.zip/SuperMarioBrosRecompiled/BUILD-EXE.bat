@echo off
setlocal enabledelayedexpansion
title Super Mario Bros. Recompiled - build the EXE
cd /d "%~dp0"

set SDL_VER=3.2.30
set OUT=SuperMarioBrosRecomp.exe
set SRC=src\main.cpp src\bus.cpp src\cpu.cpp src\ppu.cpp src\apu.cpp src\cart.cpp src\widenes.cpp

echo ==========================================================
echo   SUPER MARIO BROS. RECOMPILED - ONE CLICK BUILD
echo   This compiles %OUT% on THIS machine.
echo ==========================================================
echo.

set COMPILER=
where cl >nul 2>&1 && set COMPILER=MSVC
if "%COMPILER%"=="" (
  for %%P in ("%ProgramFiles%\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" "%ProgramFiles%\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvars64.bat" "%ProgramFiles%\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" "%ProgramFiles(x86)%\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvars64.bat") do (
    if exist %%P if "!COMPILER!"=="" (
      echo [i] Loading Visual Studio environment...
      call %%P >nul
      set COMPILER=MSVC
    )
  )
)
if "!COMPILER!"=="" ( where g++ >nul 2>&1 && set COMPILER=MINGW )
if "!COMPILER!"=="" (
  echo [X] No C++ compiler found on this PC.
  echo     Install ONE of these, then double-click this file again:
  echo       * Visual Studio 2022 Build Tools, free: https://aka.ms/vs/17/release/vs_BuildTools.exe
  echo         during setup tick "Desktop development with C++"
  echo       * or w64devkit, portable MinGW: https://github.com/skeeto/w64devkit/releases
  pause
  exit /b 1
)
echo [i] Compiler: !COMPILER!

if not exist third_party mkdir third_party
if "!COMPILER!"=="MSVC" (
  set SDLDIR=third_party\SDL3-%SDL_VER%
  set SDLPKG=SDL3-devel-%SDL_VER%-VC.zip
) else (
  set SDLDIR=third_party\SDL3-%SDL_VER%\x86_64-w64-mingw32
  set SDLPKG=SDL3-devel-%SDL_VER%-mingw.zip
)
if not exist "!SDLDIR!\include" (
  echo [i] Downloading SDL3 %SDL_VER% ...
  curl -L --fail -o "third_party\!SDLPKG!" "https://github.com/libsdl-org/SDL/releases/download/release-%SDL_VER%/!SDLPKG!"
  if errorlevel 1 ( echo [X] Download failed. Check internet, or unzip an SDL3 dev package into third_party\ yourself. & pause & exit /b 1 )
  echo [i] Extracting...
  tar -xf "third_party\!SDLPKG!" -C third_party
  if errorlevel 1 ( echo [X] Extract failed. & pause & exit /b 1 )
)
if not exist "!SDLDIR!\include" ( echo [X] SDL3 headers missing at !SDLDIR! & pause & exit /b 1 )

echo [i] Compiling the emulator core and SDL3 front-end...
if "!COMPILER!"=="MSVC" (
  cl /nologo /std:c++17 /O2 /EHsc /DNDEBUG /I "!SDLDIR!\include" %SRC% /Fe:%OUT% /link /SUBSYSTEM:WINDOWS "!SDLDIR!\lib\x64\SDL3.lib" shell32.lib
  if errorlevel 1 ( echo [X] Build failed. & pause & exit /b 1 )
  copy /y "!SDLDIR!\lib\x64\SDL3.dll" . >nul
  del *.obj >nul 2>&1
) else (
  g++ -std=c++17 -O2 -DNDEBUG -mwindows -I "!SDLDIR!\include" %SRC% -L "!SDLDIR!\lib" -lSDL3 -o %OUT%
  if errorlevel 1 ( echo [X] Build failed. & pause & exit /b 1 )
  copy /y "!SDLDIR!\bin\SDL3.dll" . >nul
)

if not exist roms mkdir rom
echo.
echo ==========================================================
echo   BUILD OK  --^>  %OUT%
echo   Put a .nes file you legally own in the rom\ folder,
echo   or just drag it onto the window.
echo ==========================================================
echo.
choice /m "Launch it now"
if errorlevel 2 goto :eof
start "" "%OUT%"
