# Super Mario Bros. Recompiled for PC

A native Windows build that runs your own legally acquired Super Mario Bros.
`.nes` dump in **widescreen**, with **controller + keyboard** support, on
**very low end hardware**.

Three pages, exactly like you asked:

1. **Library** - drag your `.nes` file onto the window, or press `O` to browse.
2. **Install** - the header is validated (mapper, CRC32, size) and the ROM is
   installed into your personal library folder, with a progress bar.
3. **Play** - the game boots straight into the widescreen recompiled view.

No ROM, BIOS, or game data ships with this project. Ever. You supply the dump.

---

## Build the EXE (one click)

Double-click **`BUILD-EXE.bat`**.

It finds your compiler, downloads SDL3, compiles
`SuperMarioBrosRecompiled.exe`, copies `SDL3.dll` next to it, and offers to
launch it. After that, **`PLAY.bat`** just runs the game.

You need a C++ compiler installed once. Either is fine:

* Visual Studio 2022 Build Tools (free) - during setup tick the
  *Desktop development with C++* workload
* w64devkit (portable MinGW, no installer, just unzip)

The script tells you where to get them if neither is present.

There is also a `CMakeLists.txt` if you prefer CMake, and
`tools/selftest.cpp` which runs the emulator core headless with no SDL at all.

---

## Controls

| Action | Keyboard | Controller |
| --- | --- | --- |
| D-pad | Arrows or WASD | D-pad or left stick |
| A | `X` or `L` | A / B face buttons |
| B | `Z` or `K` | X / Y face buttons |
| Start | `Enter` | Start |
| Select | `Shift` | Back |
| Settings | `Tab` | - |
| Reset | `R` | - |
| Back to library | `L` | - |
| Zoom the wide view | `+` / `-` | - |
| Pan the wide view | `I` `J` `K` `;` | - |

Controllers hot-plug. Plug one in mid-game and it just works, up to 4 pads.
XInput and DirectInput pads are both handled by SDL3.

---

## Widescreen: real wideNES, not a stretch

Stretching 4:3 to 16:9 just makes Mario fat. This does the real thing.

Every frame the front-end reads the PPU scroll registers per scanline, works
out how far the camera actually moved, and stitches the frames into one large
persistent map. What you get at the sides is genuine level geometry you already
walked past, dimmed slightly so the live play area still pops.

Extras it handles:

* **HUD detection** - the status bar does not scroll, so it is found via the
  mid-frame scroll split and left out of the map instead of smearing across it.
* **Scene changes** - entering a pipe or dying is a huge scroll jump, so the map
  is thrown away and rebuilt rather than glued together wrong.
* **Canvas recentre** - the map slides inside its buffer, so you can run right
  forever without running out of canvas.

Toggle it any time with `F1`. The remastered mode treats 16:9 as the actual game viewport: the complete frame fills left to right, with cached level geometry replacing the temporary side projection as you explore. F9 uses the entire monitor resolution with no black bars. Some games produce garbage maps; that toggle is
why it exists.

---

## Very low end PCs

On boot the app checks CPU cores and system RAM. Two cores or less, or 2 GB or
less, and **low-end mode turns itself on**: smaller window, wideNES off,
nearest-neighbour scaling, tighter audio buffer.

In low-end mode, if the machine falls behind, the *presentation* is dropped,
never the emulation, so audio and game logic stay at full speed and nothing
desyncs. `F2` toggles it manually.

The whole renderer is one streaming texture plus a handful of rects. It runs on
integrated graphics from 2008.

---

## What is inside

| File | What it does |
| --- | --- |
| `src/cpu.cpp` | 6502 core, all 256 opcodes including the undocumented ones |
| `src/ppu.cpp` | 2C02 picture unit: background, sprites, sprite-0 hit, scrolling |
| `src/apu.cpp` | 2 pulse, triangle, noise and DMC channels, hardware mix curve |
| `src/cart.cpp` | iNES loader, mappers 0/1/2/3/7, CRC32, battery RAM |
| `src/bus.cpp` | The machine: memory map, OAM DMA, controllers, frame timing |
| `src/widenes.cpp` | The widescreen stitching layer |
| `src/main.cpp` | SDL3 front-end: the three pages, input, audio, scaling |
| `tools/selftest.cpp` | Headless correctness check, builds without SDL |

### Verified core accuracy

`selftest` boots a tiny homebrew test ROM built in memory and asserts:

```
frames rendered : 12
cpu cycles/frame: 29771  (NTSC hardware: ~29780)
audio samples   : 8802
framebuffer     : painted
controller latch: 0x81 round-trip OK
SELFTEST PASSED
```

That is 0.03 percent off real NTSC timing, which is why the music stays in tune.

---

## Honest note on the word recompiled

True static recompilation (lifting 6502 machine code to native x86 ahead of
time) means shipping transformed copyrighted code, which nobody can legally
distribute. So this does what every legitimate PC port of a NES game actually
does: an accurate machine that runs your own dump, wrapped in a native
widescreen PC front-end. Same result, legal to share, and wideNES needs the
live PPU scroll data anyway.

## Legal

MIT licensed. Bring your own ROM. Do not distribute the EXE with game data
attached to it.
